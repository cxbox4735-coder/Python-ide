package dev.pyide;

import android.content.Context;
import android.content.SharedPreferences;

/** Impostazioni dell'app (SharedPreferences). */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("pyide", Context.MODE_PRIVATE);
    }

    boolean autosave()            { return sp.getBoolean("autosave", true); }
    void setAutosave(boolean v)   { sp.edit().putBoolean("autosave", v).apply(); }

    boolean clearLogOnRun()       { return sp.getBoolean("clear_log", true); }
    void setClearLogOnRun(boolean v) { sp.edit().putBoolean("clear_log", v).apply(); }

    boolean keepScreenOn()        { return sp.getBoolean("keep_on", false); }
    void setKeepScreenOn(boolean v) { sp.edit().putBoolean("keep_on", v).apply(); }

    int fontSize()                { return sp.getInt("font", 14); }
    void setFontSize(int v)       { sp.edit().putInt("font", v).apply(); }

    /** Limite di caratteri mantenuti nel pannello log (protegge la memoria). */
    int logLimit()                { return sp.getInt("log_limit", 150_000); }

    /** Indice pip aggiuntivo (es. repository di wheel Android). Vuoto = solo PyPI. */
    String extraIndex()           { return sp.getString("extra_index", ""); }
    void setExtraIndex(String v)  { sp.edit().putString("extra_index", v == null ? "" : v.trim()).apply(); }

    /** "embedded", "termux" oppure "" (automatico: embedded se il runtime è presente, altrimenti Termux). */
    String backend()              { return sp.getString("backend", ""); }
    void setBackend(String v)     { sp.edit().putString("backend", v == null ? "" : v).apply(); }

    /** Progetti in cartella condivisa (/sdcard/PyIDE): necessaria perché Termux possa leggerli. */
    boolean sharedProjects()      { return sp.getBoolean("shared", false); }
    void setSharedProjects(boolean v) { sp.edit().putBoolean("shared", v).apply(); }

    String lastProject()          { return sp.getString("last_project", ""); }
    void setLastProject(String v) { sp.edit().putString("last_project", v).apply(); }
}
