package dev.pyide;

import android.content.Context;
import android.os.Build;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Descrive dove si trova il runtime CPython e come avviarlo come PROCESSO separato.
 *
 * Layout atteso nell'APK (vedi README):
 *   jniLibs/<abi>/libpython_exec.so   eseguibile python rinominato (estratto in nativeLibraryDir)
 *   jniLibs/<abi>/libpython3.13.so    + librerie native necessarie (libssl, libsqlite3, ...)
 *   assets/python-stdlib.zip          libreria standard (lib/python3.13/...), estratta al primo avvio
 */
public final class PythonEnv {
    public static final String PY_TAG = "313";               // Python 3.13 -> cp313
    public static final String EXEC_NAME = "libpython_exec.so";
    private static final String MARKER = ".ready-" + PY_TAG + "-v1";

    private final Context ctx;
    public final File home;           // PYTHONHOME
    public final File sitePackages;   // librerie installate dall'utente
    public final File wheelhouse;     // copie delle wheel importate manualmente
    public final File tmp;
    public final String nativeDir;

    public PythonEnv(Context c) {
        ctx = c.getApplicationContext();
        home = new File(ctx.getFilesDir(), "python");
        sitePackages = new File(ctx.getFilesDir(), "site-packages");
        wheelhouse = new File(ctx.getFilesDir(), "wheels");
        tmp = new File(ctx.getCacheDir(), "tmp");
        nativeDir = ctx.getApplicationInfo().nativeLibraryDir;
        sitePackages.mkdirs();
        wheelhouse.mkdirs();
        tmp.mkdirs();
    }

    public File executable() {
        return new File(nativeDir, EXEC_NAME);
    }

    public boolean isBinaryPresent() {
        return executable().exists();
    }

    /** ABI del dispositivo nel formato dei tag wheel (arm64-v8a -> arm64_v8a). */
    public List<String> deviceAbis() {
        List<String> out = new ArrayList<>();
        for (String a : Build.SUPPORTED_ABIS) out.add(a.replace('-', '_'));
        return out;
    }

    /** Estrae la stdlib al primo avvio. CHIAMARE SOLO DA THREAD DI BACKGROUND. */
    public synchronized void ensureReady() throws IOException {
        if (!isBinaryPresent()) {
            throw new IOException("Runtime Python non incluso nell'APK (manca " + EXEC_NAME
                    + " in jniLibs). Vedi README, sezione \"Runtime Python\".");
        }
        if (new File(home, MARKER).exists()) return;

        FileOps.deleteQuiet(home);
        home.mkdirs();
        String base = home.getCanonicalPath() + File.separator;
        try (InputStream in = ctx.getAssets().open("python-stdlib.zip");
             ZipInputStream zin = new ZipInputStream(new BufferedInputStream(in))) {
            byte[] buf = new byte[65536];
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                File out = new File(home, e.getName());
                if (!out.getCanonicalPath().startsWith(base)) continue;      // anti zip-slip
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                out.getParentFile().mkdirs();
                try (FileOutputStream fo = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) fo.write(buf, 0, n);
                }
            }
        }
        new File(home, MARKER).createNewFile();
    }

    /** Variabili d'ambiente per ogni processo Python (script, terminale, pip). */
    public void applyEnv(Map<String, String> env) {
        String ld = env.get("LD_LIBRARY_PATH");
        env.put("LD_LIBRARY_PATH", ld == null || ld.isEmpty() ? nativeDir : nativeDir + ":" + ld);
        env.put("PYTHONHOME", home.getAbsolutePath());
        env.put("PYTHONPATH", sitePackages.getAbsolutePath());
        env.put("TMPDIR", tmp.getAbsolutePath());
        env.put("HOME", ctx.getFilesDir().getAbsolutePath());
        env.put("PYTHONUNBUFFERED", "1");
        env.put("PYTHONIOENCODING", "utf-8");
        env.put("PIP_CACHE_DIR", new File(ctx.getCacheDir(), "pip").getAbsolutePath());
        env.put("PIP_DISABLE_PIP_VERSION_CHECK", "1");
        env.put("PIP_NO_INPUT", "1");
    }
}
