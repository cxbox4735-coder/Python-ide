package dev.pyide;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.List;

/** Dialoghi degli strumenti della sidebar: Terminale, Gestore PIP, Impostazioni (UI costruita in codice). */
final class ToolDialogs {
    private ToolDialogs() {}

    /** Esegue un comando shell in Termux mostrando il log nel dialogo (implementato da MainActivity). */
    interface TermuxHook {
        void run(String shellCommand, PipManager.Callback cb);
    }

    private static LinearLayout column(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(a, 12);
        l.setPadding(p, p, p, p);
        return l;
    }

    private static TextView mono(Activity a) {
        TextView t = new TextView(a);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setTextSize(12);
        t.setTextColor(0xFFD7DAE0);
        t.setTextIsSelectable(true);
        return t;
    }

    // ------------------------------------------------------------- terminale

    static void terminal(final Activity a, final TerminalSession s, File cwd) {
        LinearLayout root = column(a);
        final TextView out = mono(a);
        final ScrollView sv = new ScrollView(a);
        sv.addView(out);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        final EditText in = new EditText(a);
        in.setSingleLine(true);
        in.setHint("comando (es. pip list)");
        in.setTypeface(android.graphics.Typeface.MONOSPACE);
        in.setImeOptions(EditorInfo.IME_ACTION_SEND);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(in, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(a);
        Button restart = new Button(a);
        restart.setText("Riavvia");
        Button stop = new Button(a);
        stop.setText("Interrompi");
        row.addView(restart, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(stop, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(row);

        final Dialog d = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
        d.setContentView(root);
        d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        final TerminalSession.Out l = new TerminalSession.Out() {
            @Override public void onText(String t) {
                out.append(t);
                sv.post(new Runnable() { @Override public void run() { sv.fullScroll(ScrollView.FOCUS_DOWN); } });
            }
        };
        s.setListener(l);
        d.setOnDismissListener(di -> s.setListener(null));
        if (!s.isAlive()) s.start(cwd);
        out.setText(s.history());

        in.setOnEditorActionListener((v, id, ev) -> {
            String cmd = in.getText().toString();
            if (!cmd.trim().isEmpty()) s.send(cmd);
            in.setText("");
            return true;
        });
        restart.setOnClickListener(v -> { s.stop(); out.setText(""); s.start(cwd); });
        stop.setOnClickListener(v -> s.stop());
        d.show();
    }

    // ------------------------------------------------------------------ pip

    static final class PipDialog {
        private final Activity a;
        private final PipManager pm;
        private final TextView log;
        private final ScrollView logScroll;
        private final ProgressBar bar;
        private final ListView list;
        private final Dialog dialog;
        private boolean busy;

        PipDialog(final Activity a, PipManager pm, final Runnable pickWheel, final TermuxHook hook) {
            this.a = a;
            this.pm = pm;
            LinearLayout root = column(a);

            final EditText name = new EditText(a);
            name.setSingleLine(true);
            name.setHint("Nome libreria esatto (es. pandas, numpy==2.1.0)");
            name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            root.addView(name);

            LinearLayout row = new LinearLayout(a);
            Button install = new Button(a);
            install.setText("Installa (auto)");
            Button wheel = new Button(a);
            wheel.setText("Importa .whl");
            row.addView(install, new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(wheel, new LinearLayout.LayoutParams(0, -2, 1f));
            root.addView(row);

            TextView tx = new TextView(a);
            tx.setText("Termux (librerie pesanti: numpy, opencv, torch...)");
            tx.setTextColor(0xFF9AA0A6);
            root.addView(tx);
            LinearLayout row2 = new LinearLayout(a);
            Button tpip = new Button(a);
            tpip.setText("pip in Termux");
            Button tpkg = new Button(a);
            tpkg.setText("pkg in Termux");
            Button trepo = new Button(a);
            trepo.setText("Repo extra");
            row2.addView(tpip, new LinearLayout.LayoutParams(0, -2, 1f));
            row2.addView(tpkg, new LinearLayout.LayoutParams(0, -2, 1f));
            row2.addView(trepo, new LinearLayout.LayoutParams(0, -2, 1f));
            root.addView(row2);

            bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
            bar.setIndeterminate(true);
            bar.setVisibility(android.view.View.GONE);
            root.addView(bar);

            log = mono(a);
            logScroll = new ScrollView(a);
            logScroll.addView(log);
            root.addView(logScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

            TextView hdr = new TextView(a);
            hdr.setText("Installate (tocco lungo per rimuovere)");
            hdr.setTextColor(0xFF9AA0A6);
            root.addView(hdr);
            list = new ListView(a);
            root.addView(list, new LinearLayout.LayoutParams(-1, Ui.dp(a, 150)));

            dialog = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
            dialog.setContentView(root);
            refreshList();

            install.setOnClickListener(v -> {
                if (busy) { Ui.toast(a, "Un'installazione è già in corso"); return; }
                String spec = name.getText().toString();
                log.setText("");
                setBusy(true);
                RunnerService.start(a, "Installazione librerie in corso");
                PipDialog.this.pm.install(spec, callback());
            });
            tpip.setOnClickListener(v -> {
                if (busy) { Ui.toast(a, "Un'operazione è già in corso"); return; }
                List<String> specs = PipManager.parseSpecs(name.getText().toString());
                if (specs == null) { Ui.toast(a, "Nome non valido (es. numpy, pandas==2.2.0)"); return; }
                String cmd = "V=\"$HOME/.pyide-venv\"; [ -x \"$V/bin/python\" ] || python -m venv --without-pip "
                        + "--system-site-packages \"$V\" || exit 1; \"$V/bin/python\" -m pip install --upgrade "
                        + "--prefer-binary --progress-bar off --extra-index-url " + TermuxBridge.TUR_INDEX + " "
                        + android.text.TextUtils.join(" ", specs);
                startTermux(hook, cmd);
            });
            tpkg.setOnClickListener(v -> {
                if (busy) { Ui.toast(a, "Un'operazione è già in corso"); return; }
                String[] names = name.getText().toString().trim().split("\\s+");
                StringBuilder sb = new StringBuilder();
                for (String n : names) {
                    if (!n.matches("^[a-z0-9][a-z0-9.+\\-]*$")) { Ui.toast(a, "Nome pkg non valido: " + n); return; }
                    sb.append(' ').append(n);
                }
                startTermux(hook, "yes | pkg install -y" + sb);
            });
            trepo.setOnClickListener(v -> {
                if (busy) { Ui.toast(a, "Un'operazione è già in corso"); return; }
                startTermux(hook, "yes | pkg install -y tur-repo x11-repo && yes | pkg update");
            });
            wheel.setOnClickListener(v -> {
                if (busy) { Ui.toast(a, "Un'installazione è già in corso"); return; }
                pickWheel.run();
            });
            list.setOnItemLongClickListener((p, v, pos, id) -> {
                final String entry = (String) list.getItemAtPosition(pos);
                final String pkg = entry.split(" ")[0];
                Ui.confirm(a, "Rimuovere " + pkg + "?", "Verranno eliminati i file del pacchetto.", () ->
                        PipDialog.this.pm.uninstall(pkg, new PipManager.Callback() {
                            @Override public void onLog(String line) { }
                            @Override public void onDone(boolean ok, String message) {
                                Ui.toast(a, message);
                                refreshList();
                            }
                        }));
                return true;
            });
        }

        void show() {
            dialog.show();
        }

        private void startTermux(TermuxHook hook, String cmd) {
            log.setText("");
            setBusy(true);
            hook.run(cmd, callback());
        }

        /** Da chiamare da Activity.onActivityResult con la wheel scelta dall'utente. */
        void onWheelPicked(Uri uri) {
            log.setText("");
            setBusy(true);
            RunnerService.start(a, "Installazione libreria in corso");
            pm.installWheel(uri, callback());
            if (!dialog.isShowing()) dialog.show();
        }

        private PipManager.Callback callback() {
            return new PipManager.Callback() {
                @Override public void onLog(String line) {
                    log.append(line + "\n");
                    logScroll.post(new Runnable() { @Override public void run() { logScroll.fullScroll(ScrollView.FOCUS_DOWN); } });
                }

                @Override public void onDone(boolean ok, String message) {
                    setBusy(false);
                    RunnerService.stop(a);
                    log.append((ok ? "\n✔ " : "\n✖ ") + message + "\n");
                    new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                            .setTitle(ok ? "Installazione completata" : "Installazione non riuscita")
                            .setMessage(message).setPositiveButton("OK", null).show();
                    refreshList();
                }
            };
        }

        private void setBusy(boolean b) {
            busy = b;
            bar.setVisibility(b ? android.view.View.VISIBLE : android.view.View.GONE);
        }

        private void refreshList() {
            List<String> items = pm.installed();
            ArrayAdapter<String> ad = new ArrayAdapter<>(a, android.R.layout.simple_list_item_1, items);
            list.setAdapter(ad);
        }
    }

    // ---------------------------------------------------------- impostazioni

    static void settings(final Activity a, final Prefs p, String backend, final Runnable onChanged) {
        LinearLayout root = column(a);

        final CheckBox auto = check(a, "Autosalvataggio in tempo reale", p.autosave());
        final CheckBox clr = check(a, "Svuota il log ad ogni esecuzione", p.clearLogOnRun());
        final CheckBox keep = check(a, "Tieni lo schermo acceso", p.keepScreenOn());
        root.addView(auto);
        root.addView(clr);
        root.addView(keep);

        TextView bl = new TextView(a);
        bl.setText("Dove eseguire gli script");
        bl.setPadding(0, Ui.dp(a, 10), 0, 0);
        root.addView(bl);
        final android.widget.RadioGroup rg = new android.widget.RadioGroup(a);
        final android.widget.RadioButton rEmb = new android.widget.RadioButton(a);
        rEmb.setText("Runtime incorporato (solo se incluso nell'APK)");
        rEmb.setId(1001);
        final android.widget.RadioButton rTer = new android.widget.RadioButton(a);
        rTer.setText("Termux (librerie complete: numpy, opencv, torch...)");
        rTer.setId(1002);
        rg.addView(rEmb);
        rg.addView(rTer);
        rg.check(backend.equals("termux") ? 1002 : 1001);
        root.addView(rg);
        final CheckBox shared = check(a, "Progetti in cartella condivisa /sdcard/PyIDE (obbligatorio con Termux)", p.sharedProjects());
        root.addView(shared);

        final TextView fl = new TextView(a);
        fl.setText("Dimensione carattere: " + p.fontSize());
        root.addView(fl);
        final SeekBar sb = new SeekBar(a);
        sb.setMax(14);                                  // 10..24
        sb.setProgress(p.fontSize() - 10);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean u) { fl.setText("Dimensione carattere: " + (v + 10)); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(sb);

        TextView il = new TextView(a);
        il.setText("Indice pip aggiuntivo (https://..., facoltativo: repository con wheel Android)");
        root.addView(il);
        final EditText idx = new EditText(a);
        idx.setSingleLine(true);
        idx.setText(p.extraIndex());
        root.addView(idx);

        ScrollView sv = new ScrollView(a);
        sv.addView(root);
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert).setTitle("Impostazioni").setView(sv)
                .setNegativeButton("Annulla", null)
                .setPositiveButton("Salva", (d, w) -> {
                    p.setBackend(rg.getCheckedRadioButtonId() == 1002 ? "termux" : "embedded");
                    p.setSharedProjects(shared.isChecked() || rg.getCheckedRadioButtonId() == 1002);
                    p.setAutosave(auto.isChecked());
                    p.setClearLogOnRun(clr.isChecked());
                    p.setKeepScreenOn(keep.isChecked());
                    p.setFontSize(sb.getProgress() + 10);
                    p.setExtraIndex(idx.getText().toString());
                    onChanged.run();
                }).show();
    }

    private static CheckBox check(Activity a, String t, boolean v) {
        CheckBox c = new CheckBox(a);
        c.setText(t);
        c.setChecked(v);
        return c;
    }
}
