package dev.pyide;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.os.Handler;
import android.os.Looper;

/**
 * Terminale integrato: shell di sistema (/system/bin/sh) collegata con pipe, con le funzioni
 * python / pip / python3 che puntano al runtime dell'app. Non è un PTY: niente programmi a schermo
 * intero (vim, htop) né Ctrl-C reale; "Interrompi" termina la sessione.
 */
final class TerminalSession {
    interface Out {
        void onText(String s);
    }

    private final PythonEnv env;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final StringBuilder history = new StringBuilder();
    private volatile Process process;
    private volatile OutputStream stdin;
    private volatile Out listener;

    TerminalSession(PythonEnv env) {
        this.env = env;
    }

    boolean isAlive() {
        Process p = process;
        return p != null && p.isAlive();
    }

    String history() {
        return history.toString();
    }

    void setListener(Out l) {
        listener = l;
    }

    void start(final File cwd) {
        if (isAlive()) return;
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    env.ensureReady();
                    ProcessBuilder pb = new ProcessBuilder("/system/bin/sh");
                    pb.directory(cwd);
                    pb.redirectErrorStream(true);
                    env.applyEnv(pb.environment());
                    final Process p = pb.start();
                    process = p;
                    stdin = p.getOutputStream();
                    String py = env.executable().getAbsolutePath();
                    write("python() { '" + py + "' \"$@\"; }; python3() { python \"$@\"; }; "
                            + "pip() { python -m pip \"$@\"; }\n");
                    append("Terminale PyIDE - comandi: python, pip, ls, cat, cd...\n");
                    try (InputStreamReader r = new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8)) {
                        char[] buf = new char[4096];
                        int n;
                        while ((n = r.read(buf)) > 0) append(new String(buf, 0, n));
                    }
                    append("\n[sessione terminata]\n");
                } catch (Exception e) {
                    append("Errore: " + e.getMessage() + "\n");
                } finally {
                    process = null;
                    stdin = null;
                }
            }
        });
    }

    void send(final String cmd) {
        append("$ " + cmd + "\n");
        write(cmd + "\n");
    }

    void stop() {
        Process p = process;
        if (p != null) p.destroyForcibly();
    }

    private void write(final String s) {
        final OutputStream o = stdin;
        if (o == null) return;
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    o.write(s.getBytes(StandardCharsets.UTF_8));
                    o.flush();
                } catch (IOException ignored) {
                }
            }
        });
    }

    private void append(final String s) {
        ui.post(new Runnable() {
            @Override public void run() {
                history.append(s);
                if (history.length() > 100_000) history.delete(0, history.length() - 80_000);
                Out l = listener;
                if (l != null) l.onText(s);
            }
        });
    }
}
