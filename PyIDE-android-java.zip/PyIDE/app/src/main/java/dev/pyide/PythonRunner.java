package dev.pyide;

import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Esegue lo script Python come PROCESSO separato (non nel processo dell'app):
 *  - la UI non si blocca mai (tutto gira su thread dedicati, callback sul main thread);
 *  - un loop infinito o un crash nativo (NumPy, torch...) non abbattono l'IDE;
 *  - Stop = destroy() del processo, sempre possibile.
 */
final class PythonRunner implements ScriptRunner {
    private final PythonEnv env;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile Process process;
    private volatile OutputStream stdin;
    private volatile boolean stopRequested;

    PythonRunner(PythonEnv env) {
        this.env = env;
    }

    @Override public boolean isRunning() {
        Process p = process;
        return p != null && p.isAlive();
    }

    @Override public synchronized void run(final File workDir, final File script, final Listener l) {
        if (isRunning()) return;
        stopRequested = false;
        pool.execute(new Runnable() {
            @Override public void run() {
                long t0 = System.currentTimeMillis();
                int code = -1;
                ui.post(new Runnable() { @Override public void run() { l.onStart(); } });
                try {
                    env.ensureReady();
                    ProcessBuilder pb = new ProcessBuilder(env.executable().getAbsolutePath(), "-u",
                            script.getAbsolutePath());
                    pb.directory(workDir);
                    env.applyEnv(pb.environment());
                    Process p = pb.start();
                    process = p;
                    stdin = p.getOutputStream();
                    Thread out = pump(p.getInputStream(), false, l);
                    Thread err = pump(p.getErrorStream(), true, l);
                    code = p.waitFor();
                    out.join(2000);
                    err.join(2000);
                } catch (final Exception e) {
                    ui.post(new Runnable() {
                        @Override public void run() { l.onOutput("Errore di avvio: " + e.getMessage() + "\n", true); }
                    });
                } finally {
                    process = null;
                    stdin = null;
                }
                final int c = code;
                final long dt = System.currentTimeMillis() - t0;
                final boolean stopped = stopRequested;
                ui.post(new Runnable() { @Override public void run() { l.onFinish(c, dt, stopped); } });
            }
        });
    }

    private Thread pump(final InputStream in, final boolean isErr, final Listener l) {
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                char[] buf = new char[4096];
                try (InputStreamReader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                    int n;
                    while ((n = r.read(buf)) > 0) {
                        final String s = new String(buf, 0, n);
                        ui.post(new Runnable() { @Override public void run() { l.onOutput(s, isErr); } });
                    }
                } catch (IOException ignored) {
                }
            }
        }, isErr ? "py-stderr" : "py-stdout");
        t.setDaemon(true);
        t.start();
        return t;
    }

    /** Interrompe il processo (bot, server, loop infiniti). Prima gentile, poi forzato. */
    @Override public void stop() {
        final Process p = process;
        if (p == null) return;
        stopRequested = true;
        p.destroy();                                              // SIGTERM
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (!p.waitFor(1500, TimeUnit.MILLISECONDS)) p.destroyForcibly();   // SIGKILL
                } catch (InterruptedException ignored) {
                }
            }
        });
    }

    /** Invia una riga allo stdin dello script (per input()). */
    @Override public boolean sendInput(final String line) {
        final OutputStream o = stdin;
        if (o == null) return false;
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    o.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                    o.flush();
                } catch (IOException ignored) {
                }
            }
        });
        return true;
    }
}
