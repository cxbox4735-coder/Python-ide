package dev.pyide;

import java.io.File;

/**
 * Esegue lo script nell'ambiente Termux: libreria completa (pkg/pip di Termux, wheel, compilatori,
 * NumPy/OpenCV/...). Usa un venv condiviso (~/.pyide-venv, con --system-site-packages) se esiste.
 */
final class TermuxRunner implements ScriptRunner {
    static final String PYTHON_PICK =
            "V=\"$HOME/.pyide-venv\"; PY=python; [ -x \"$V/bin/python\" ] && PY=\"$V/bin/python\"; ";

    private final TermuxBridge bridge;
    private TermuxJob job;

    TermuxRunner(TermuxBridge bridge) {
        this.bridge = bridge;
    }

    @Override public boolean isRunning() {
        return job != null && job.isRunning();
    }

    @Override public void run(File workDir, File script, final Listener l) {
        if (isRunning()) return;
        final long t0 = System.currentTimeMillis();
        l.onStart();
        job = new TermuxJob(bridge, new File(workDir, ".pyide/run"));
        String cmd = PYTHON_PICK + "exec \"$PY\" -u " + TermuxBridge.q(script.getAbsolutePath());
        String err = job.start(cmd, workDir.getAbsolutePath(), new TermuxJob.Listener() {
            @Override public void onOutput(String text, boolean isError) {
                l.onOutput(text, isError);
            }

            @Override public void onExit(int code, boolean stopped, String problem) {
                if (problem != null) l.onOutput(problem + "\n", true);
                else if (code == 127) l.onOutput("Python non trovato in Termux: esegui  pkg install python\n", true);
                l.onFinish(problem != null ? -1 : code, System.currentTimeMillis() - t0, stopped);
            }
        });
        if (err != null) {
            l.onOutput(err + "\n", true);
            l.onFinish(-1, 0, false);
        }
    }

    @Override public void stop() {
        if (job != null) job.stop();
    }

    @Override public boolean sendInput(String line) {
        return false;                    // stdin non disponibile con Termux in background
    }
}
