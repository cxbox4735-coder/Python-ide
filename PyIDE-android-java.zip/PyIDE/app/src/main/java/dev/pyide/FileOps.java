package dev.pyide;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Operazioni sui file, tutte vincolate alla cartella radice del progetto. Eseguire in background. */
public final class FileOps {
    private FileOps() {}

    public static String validName(String name) throws IOException {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.equals(".") || n.equals("..") || n.contains("/") || n.contains("\\")
                || n.indexOf('\0') >= 0) {
            throw new IOException("Nome non valido: \"" + n + "\"");
        }
        return n;
    }

    public static boolean isInside(File root, File f) {
        try {
            String r = root.getCanonicalPath();
            String p = f.getCanonicalPath();
            return p.equals(r) || p.startsWith(r + File.separator);
        } catch (IOException e) {
            return false;
        }
    }

    public static File createFile(File root, File parent, String name) throws IOException {
        File f = new File(parent, validName(name));
        if (!isInside(root, f)) throw new IOException("Percorso fuori dal progetto");
        if (f.exists()) throw new IOException("\"" + f.getName() + "\" esiste già");
        if (f.getParentFile() != null) f.getParentFile().mkdirs();
        if (!f.createNewFile()) throw new IOException("Impossibile creare il file");
        return f;
    }

    public static File createDir(File root, File parent, String name) throws IOException {
        File f = new File(parent, validName(name));
        if (!isInside(root, f)) throw new IOException("Percorso fuori dal progetto");
        if (f.exists()) throw new IOException("\"" + f.getName() + "\" esiste già");
        if (!f.mkdirs()) throw new IOException("Impossibile creare la cartella");
        return f;
    }

    public static File rename(File root, File f, String newName) throws IOException {
        File dst = new File(f.getParentFile(), validName(newName));
        if (!isInside(root, dst)) throw new IOException("Percorso fuori dal progetto");
        if (dst.exists()) throw new IOException("\"" + dst.getName() + "\" esiste già");
        if (!f.renameTo(dst)) throw new IOException("Rinomina non riuscita");
        return dst;
    }

    public static File move(File root, File f, File destDir) throws IOException {
        if (!destDir.isDirectory()) throw new IOException("Destinazione non valida");
        if (isInside(f, destDir)) throw new IOException("Non puoi spostare una cartella dentro sé stessa");
        File dst = new File(destDir, f.getName());
        if (!isInside(root, dst)) throw new IOException("Percorso fuori dal progetto");
        if (dst.exists()) throw new IOException("Nella destinazione esiste già \"" + f.getName() + "\"");
        if (!f.renameTo(dst)) throw new IOException("Spostamento non riuscito");
        return dst;
    }

    public static void delete(File root, File f) throws IOException {
        if (!isInside(root, f) || f.equals(root)) throw new IOException("Eliminazione non consentita");
        deleteRecursive(f);
    }

    private static void deleteRecursive(File f) throws IOException {
        // i link simbolici si scollegano senza seguirli
        if (f.isDirectory() && !java.nio.file.Files.isSymbolicLink(f.toPath())) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        if (!f.delete() && f.exists()) throw new IOException("Impossibile eliminare " + f.getName());
    }

    public static void deleteQuiet(File f) {
        try {
            deleteRecursive(f);
        } catch (IOException ignored) {
        }
    }

    /** Tutte le sottocartelle (incluso il root) per la scelta della destinazione di "Sposta". */
    public static List<File> listDirs(File root) {
        List<File> out = new ArrayList<>();
        out.add(root);
        collect(root, out, 0);
        return out;
    }

    private static void collect(File dir, List<File> out, int depth) {
        if (depth > 8) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        Arrays.sort(kids, new Comparator<File>() {
            @Override public int compare(File a, File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        for (File k : kids) {
            if (k.isDirectory() && !k.getName().startsWith(".")) {
                out.add(k);
                collect(k, out, depth + 1);
            }
        }
    }
}
