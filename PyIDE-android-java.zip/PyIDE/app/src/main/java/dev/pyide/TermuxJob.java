package dev.pyide;

import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Esegue un comando in Termux (in background) e ne segue l'output IN TEMPO REALE.
 * Termux scrive stdout/stderr/pid/exit in file dentro una cartella CONDIVISA (job dir) che questa
 * app legge ogni 200 ms. Funziona perché entrambe le app accedono allo storage condiviso.
 * Stop = kill del pid registrato. Il job sopravvive alla chiusura di PyIDE (utile per i bot).
 */
final class TermuxJob {
    interface Listener {
        void onOutput(String text, boolean isError);
        /** problem != null: Termux non ha avviato il comando (spiegazione per l'utente). */
        void onExit(int code, boolean stopped, String problem);
    }

    private static final long START_TIMEOUT_MS = 10_000;

    private final TermuxBridge bridge;
    private final File dir;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean running, stopped;

    TermuxJob(TermuxBridge bridge, File dir) {
        this.bridge = bridge;
        this.dir = dir;
    }

    boolean isRunning() {
        return running;
    }

    /** @return messaggio d'errore immediato, oppure null se il job è partito. */
    String start(String command, String workdir, final Listener l) {
        if (running) return "Già in esecuzione.";
        if (!dir.exists() && !dir.mkdirs()) return "Impossibile creare la cartella condivisa " + dir;
        for (String n : new String[]{"out", "err", "pid", "exit"}) new File(dir, n).delete();
        stopped = false;

        String script =
                "J=" + TermuxBridge.q(dir.getAbsolutePath()) + "\n"
                + "cd " + TermuxBridge.q(workdir) + " 2>\"$J/err\" || { echo 1 > \"$J/exit\"; exit 1; }\n"
                + "export PYTHONUNBUFFERED=1 PYTHONIOENCODING=utf-8\n"
                + "bash -c " + TermuxBridge.q(command) + " >\"$J/out\" 2>>\"$J/err\" </dev/null &\n"
                + "echo $! > \"$J/pid\"\n"
                + "wait $!\n"
                + "echo $? > \"$J/exit\"\n";

        String err = bridge.runBackground(script, TermuxBridge.HOME);
        if (err != null) return err;
        running = true;

        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                File fo = new File(dir, "out"), fe = new File(dir, "err"),
                        fp = new File(dir, "pid"), fx = new File(dir, "exit");
                long offOut = 0, offErr = 0, t0 = System.currentTimeMillis();
                int code = -1;
                String problem = null;
                try {
                    while (true) {
                        offOut = drain(fo, offOut, false, l);
                        offErr = drain(fe, offErr, true, l);
                        if (fx.exists() && fx.length() > 0) {
                            Thread.sleep(250);                       // ultimo svuotamento
                            drain(fo, offOut, false, l);
                            drain(fe, offErr, true, l);
                            try {
                                code = Integer.parseInt(new String(Files.readAllBytes(fx.toPath()),
                                        StandardCharsets.UTF_8).trim());
                            } catch (IOException | NumberFormatException ignored) {
                            }
                            break;
                        }
                        if (!fp.exists() && !fx.exists() && System.currentTimeMillis() - t0 > START_TIMEOUT_MS) {
                            problem = "Termux non ha avviato il comando. Controlla: Termux aperto almeno una volta, "
                                    + "allow-external-apps=true, permesso \"Esegui comandi in Termux\" a PyIDE e "
                                    + "storage condiviso concesso a Termux (termux-setup-storage).";
                            break;
                        }
                        Thread.sleep(200);
                    }
                } catch (InterruptedException ignored) {
                }
                running = false;
                final int c = code;
                final String p = problem;
                ui.post(new Runnable() { @Override public void run() { l.onExit(c, stopped, p); } });
            }
        }, "termux-tail");
        t.setDaemon(true);
        t.start();
        return null;
    }

    void stop() {
        if (!running) return;
        stopped = true;
        String j = TermuxBridge.q(dir.getAbsolutePath());
        bridge.runBackground(
                "J=" + j + "\nP=$(cat \"$J/pid\" 2>/dev/null)\n[ -n \"$P\" ] || exit 0\n"
                + "command -v pkill >/dev/null 2>&1 && pkill -TERM -P \"$P\"\nkill -TERM \"$P\" 2>/dev/null\nsleep 2\n"
                + "command -v pkill >/dev/null 2>&1 && pkill -KILL -P \"$P\"\nkill -KILL \"$P\" 2>/dev/null\n"
                + "[ -s \"$J/exit\" ] || echo 143 > \"$J/exit\"\n", TermuxBridge.HOME);
    }

    private long drain(File f, long off, final boolean isErr, final Listener l) {
        if (!f.exists() || f.length() <= off) return off;
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            int len = (int) Math.min(r.length() - off, 256 * 1024);
            if (len <= 0) return off;
            byte[] b = new byte[len];
            r.seek(off);
            r.readFully(b);
            int use = utf8Boundary(b);
            if (use == 0) return off;
            final String s = new String(b, 0, use, StandardCharsets.UTF_8);
            ui.post(new Runnable() { @Override public void run() { l.onOutput(s, isErr); } });
            return off + use;
        } catch (IOException e) {
            return off;
        }
    }

    /** Lunghezza utilizzabile senza spezzare una sequenza UTF-8 incompleta in coda. */
    static int utf8Boundary(byte[] b) {
        int n = b.length, i = n - 1, back = 0;
        while (i >= 0 && back < 4 && (b[i] & 0xC0) == 0x80) { i--; back++; }
        if (i < 0) return n;
        int lead = b[i] & 0xFF;
        int need = lead >= 0xF0 ? 4 : lead >= 0xE0 ? 3 : lead >= 0xC0 ? 2 : 1;
        return (n - i) >= need ? n : i;
    }
}
