package dev.pyide;

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Gestione dei progetti: ogni progetto è una cartella con un file di config ".pyide.json". */
final class ProjectManager {
    static final String CONFIG = ".pyide.json";
    private static final String TEMPLATE =
            "# Entry point del progetto: il tasto Play avvia SEMPRE questo file.\n"
            + "def main():\n"
            + "    print(\"Ciao da PyIDE!\")\n\n\n"
            + "if __name__ == \"__main__\":\n"
            + "    main()\n";

    private final File root;

    private final boolean shared;

    /** @param wantShared true = /sdcard/PyIDE/projects (richiede "accesso a tutti i file"); se non scrivibile ripiega sulla cartella dell'app. */
    ProjectManager(Context c, boolean wantShared) {
        File r = null;
        boolean sh = false;
        if (wantShared) {
            File s = new File(android.os.Environment.getExternalStorageDirectory(), "PyIDE/projects");
            s.mkdirs();
            if (s.isDirectory() && s.canWrite()) { r = s; sh = true; }
        }
        if (r == null) {
            File ext = c.getExternalFilesDir("projects");
            r = ext != null ? ext : new File(c.getFilesDir(), "projects");
            r.mkdirs();
        }
        root = r;
        shared = sh;
    }

    File root() { return root; }

    boolean isShared() { return shared; }

    List<String> list() {
        List<String> names = new ArrayList<>();
        File[] kids = root.listFiles();
        if (kids != null) for (File k : kids) if (k.isDirectory() && !k.getName().startsWith(".")) names.add(k.getName());
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    File dir(String name) {
        return new File(root, name);
    }


    File create(String name) throws IOException {
        File d = new File(root, FileOps.validName(name));
        if (d.exists()) throw new IOException("Esiste già un progetto con questo nome");
        if (!d.mkdirs()) throw new IOException("Impossibile creare la cartella del progetto");
        write(new File(d, "main.py"), TEMPLATE);
        saveConfig(d, "main.py");
        return d;
    }

    void delete(File project) throws IOException {
        FileOps.delete(root, project);
    }

    /** Script di partenza del progetto (default main.py). */
    File getEntry(File project) {
        String rel = "main.py";
        try {
            File cfg = new File(project, CONFIG);
            if (cfg.exists()) {
                byte[] b = java.nio.file.Files.readAllBytes(cfg.toPath());
                rel = new JSONObject(new String(b, StandardCharsets.UTF_8)).optString("entry", "main.py");
            }
        } catch (IOException | JSONException ignored) {
        }
        File f = new File(project, rel);
        return FileOps.isInside(project, f) ? f : new File(project, "main.py");
    }

    void setEntry(File project, File file) throws IOException {
        if (!FileOps.isInside(project, file)) throw new IOException("Il file non appartiene al progetto");
        saveConfig(project, relative(project, file));
    }

    String relative(File project, File f) {
        return project.toURI().relativize(f.toURI()).getPath();
    }

    private void saveConfig(File project, String entryRel) throws IOException {
        try {
            write(new File(project, CONFIG), new JSONObject().put("entry", entryRel).toString(2));
        } catch (JSONException e) {
            throw new IOException(e);
        }
    }

    static void write(File f, String content) throws IOException {
        try (FileOutputStream out = new FileOutputStream(f)) {
            out.write(content.getBytes(StandardCharsets.UTF_8));
        }
    }
}
