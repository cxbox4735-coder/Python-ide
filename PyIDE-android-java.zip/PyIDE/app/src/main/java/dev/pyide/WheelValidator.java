package dev.pyide;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

/**
 * Valida un file .whl prima dell'installazione manuale.
 * Verifica: nome, integrità dello ZIP (CRC), struttura .dist-info e compatibilità
 * dei tag (versione Python, ABI, piattaforma) con il runtime Python dell'app.
 * Java puro: nessuna dipendenza Android.
 */
public final class WheelValidator {

    public static final class Result {
        public final boolean ok;
        public final String message;      // spiegazione in italiano (errore o riepilogo)
        public final String dist, version;
        public final List<String> requires;

        Result(boolean ok, String message, String dist, String version, List<String> requires) {
            this.ok = ok;
            this.message = message;
            this.dist = dist;
            this.version = version;
            this.requires = requires;
        }

        static Result fail(String msg) {
            return new Result(false, msg, "", "", new ArrayList<String>());
        }
    }

    private WheelValidator() {}

    /**
     * @param pyTag      versione del runtime, es. "313" (Python 3.13)
     * @param deviceAbis ABI del dispositivo con '_' al posto di '-', es. "arm64_v8a"
     */
    public static Result validate(File whl, String pyTag, List<String> deviceAbis) {
        int minor = Integer.parseInt(pyTag.substring(1));
        String pyHuman = "3." + minor;

        if (whl == null || !whl.isFile()) return Result.fail("File non trovato o non leggibile.");
        String name = whl.getName();
        if (!name.toLowerCase().endsWith(".whl")) {
            return Result.fail("Il file \"" + name + "\" non è una wheel (.whl). "
                    + "Sono supportate solo wheel; per i sorgenti usa la modalità automatica.");
        }

        // 1) nome: distribuzione-versione[-build]-python-abi-piattaforma.whl
        String[] p = name.substring(0, name.length() - 4).split("-");
        if (p.length < 5 || p.length > 6) {
            return Result.fail("Nome file non valido: atteso "
                    + "distribuzione-versione-python-abi-piattaforma.whl. Il file potrebbe essere stato rinominato.");
        }
        String dist = p[0], version = p[1];
        String[] pyTags = p[p.length - 3].split("\\.");
        String[] abiTags = p[p.length - 2].split("\\.");
        String[] platTags = p[p.length - 1].split("\\.");

        // 2) integrità ZIP + struttura wheel
        String metadata = null;
        boolean hasWheelFile = false;
        try (ZipFile zf = new ZipFile(whl)) {
            byte[] buf = new byte[65536];
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                boolean isMeta = n.endsWith(".dist-info/METADATA");
                if (n.endsWith(".dist-info/WHEEL")) hasWheelFile = true;
                java.util.zip.CRC32 crc = new java.util.zip.CRC32();
                try (InputStream in = zf.getInputStream(e)) {   // legge tutto: verifica il CRC
                    java.io.ByteArrayOutputStream bos = isMeta ? new java.io.ByteArrayOutputStream() : null;
                    int r;
                    while ((r = in.read(buf)) > 0) {
                        crc.update(buf, 0, r);
                        if (bos != null) bos.write(buf, 0, r);
                    }
                    if (bos != null) metadata = bos.toString("UTF-8");
                }
                if (e.getCrc() != -1 && e.getCrc() != crc.getValue()) {
                    throw new ZipException("CRC errato in " + n);
                }
            }
        } catch (ZipException e) {
            return Result.fail("File corrotto: l'archivio ZIP non è valido o il download è incompleto ("
                    + e.getMessage() + "). Riscaricalo.");
        } catch (IOException e) {
            return Result.fail("Impossibile leggere il file: " + e.getMessage());
        }
        if (!hasWheelFile || metadata == null) {
            return Result.fail("Wheel non valida: mancano i file .dist-info/WHEEL o METADATA.");
        }

        // 3) piattaforma
        boolean platOk = false;
        for (String t : platTags) {
            if (t.equals("any")) platOk = true;
            for (String abi : deviceAbis) {
                if (t.startsWith("android_") && t.endsWith("_" + abi)) platOk = true;
            }
        }
        if (!platOk) {
            String joined = p[p.length - 1];
            String why;
            if (joined.contains("manylinux") || joined.contains("musllinux") || joined.startsWith("linux_")) {
                why = "è una wheel per Linux desktop (glibc/musl), non utilizzabile su Android";
            } else if (joined.startsWith("win")) {
                why = "è una wheel per Windows";
            } else if (joined.startsWith("macosx")) {
                why = "è una wheel per macOS";
            } else if (joined.startsWith("android_")) {
                why = "è per un'altra architettura Android (questo dispositivo: " + deviceAbis + ")";
            } else {
                why = "piattaforma sconosciuta";
            }
            return Result.fail("Non compatibile: " + why + " (tag: " + joined + "). "
                    + "Serve un tag \"any\" (pura Python) oppure \"android_*_" + deviceAbis.get(0) + "\".");
        }

        // 4) versione Python e ABI
        boolean abi3 = false;
        for (String a : abiTags) if (a.equals("abi3")) abi3 = true;

        boolean pyOk = false;
        for (String t : pyTags) {
            Matcher m = Pattern.compile("^(?:py|cp)3(\\d*)$").matcher(t);
            if (!m.matches()) continue;
            if (t.startsWith("py")) {
                if (m.group(1).isEmpty() || Integer.parseInt(m.group(1)) <= minor) pyOk = true;
            } else if (!m.group(1).isEmpty()) {
                int n = Integer.parseInt(m.group(1));
                if (n == minor || (abi3 && n <= minor)) pyOk = true;
            }
        }
        if (!pyOk) {
            return Result.fail("Non compatibile: la wheel è per Python " + p[p.length - 3]
                    + ", mentre l'app usa Python " + pyHuman + " (cp" + pyTag + ").");
        }

        boolean abiOk = false;
        for (String a : abiTags) {
            if (a.equals("none") || a.equals("abi3") || a.equals("cp" + pyTag)) abiOk = true;
        }
        if (!abiOk) {
            return Result.fail("Non compatibile: ABI \"" + p[p.length - 2] + "\" diversa da cp" + pyTag + ".");
        }

        // 5) dipendenze dichiarate (solo informative: l'installazione manuale è con --no-deps)
        List<String> req = new ArrayList<>();
        for (String line : metadata.split("\r?\n")) {
            if (line.isEmpty()) break;                       // fine degli header
            if (line.startsWith("Requires-Dist:") && !line.contains("extra ==")) {
                req.add(line.substring("Requires-Dist:".length()).trim());
            }
        }
        return new Result(true, "Wheel valida: " + dist + " " + version, dist, version, req);
    }
}
