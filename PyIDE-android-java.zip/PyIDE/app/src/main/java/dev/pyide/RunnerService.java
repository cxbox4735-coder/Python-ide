package dev.pyide;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * Foreground service: tiene vivo il processo dell'app mentre uno script (bot, server) o un'installazione
 * pip sono in esecuzione, anche con lo schermo spento o l'app in secondo piano.
 */
public class RunnerService extends Service {
    private static final String CH = "pyide_run";

    static void start(Context c, String text) {
        Intent i = new Intent(c, RunnerService.class).putExtra("text", text);
        try {
            c.startForegroundService(i);
        } catch (RuntimeException ignored) {          // app in background senza permesso: si esegue comunque
        }
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, RunnerService.class));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Esecuzione script", NotificationManager.IMPORTANCE_LOW));
        String text = intent != null && intent.getStringExtra("text") != null ? intent.getStringExtra("text") : "In esecuzione";
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CH)
                .setContentTitle("PyIDE").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).setContentIntent(pi).build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
