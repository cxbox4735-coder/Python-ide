package dev.pyide;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Layout;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Editor di codice senza dipendenze esterne:
 *  - Undo/Redo con cronologia propria (digitazione consecutiva unita in un solo passo)
 *  - Vai alla linea, Cerca / Sostituisci / Sostituisci tutto
 *  - numeri di riga fissi, righe di errore/causa evidenziate (barra colorata + pallino)
 *  - evidenziazione sintassi con debounce, auto-indentazione (Python: dopo ':' +4 spazi)
 */
public class CodeEditText extends EditText {

    public interface OnContentChanged {
        void onChanged();
    }

    private static final class Edit {
        final int start;
        final String oldText, newText;
        Edit(int s, String o, String n) { start = s; oldText = o; newText = n; }
    }

    private final Paint gutterBg = new Paint();
    private final Paint gutterText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint();
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Map<Integer, Integer> marks = new HashMap<>();
    private final ArrayList<Edit> undo = new ArrayList<>();
    private final ArrayList<Edit> redo = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final BackgroundColorSpan findSpan = new BackgroundColorSpan(0x88FFD54F);

    private final Runnable highlightTask = new Runnable() {
        @Override public void run() { SyntaxHighlighter.apply(getText(), language); }
    };

    private String language = "text";
    private int gutterWidth;
    private boolean applyingHistory, suppress;
    private String pendingOld = "";
    private OnContentChanged listener;

    public CodeEditText(Context c) {
        super(c);
        init();
    }

    public CodeEditText(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        setTypeface(Typeface.MONOSPACE);
        setTextSize(14);
        setBackgroundColor(0xFF1E1F22);
        setTextColor(0xFFD7DAE0);
        setHighlightColor(0x663D5AFE);
        setGravity(Gravity.TOP | Gravity.START);
        setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        setHorizontallyScrolling(true);          // DOPO setInputType, che lo azzera
        setFilters(new InputFilter[]{new AutoIndentFilter()});

        gutterBg.setColor(0xFF25272B);
        dotPaint.setColor(0xFFFF453A);
        gutterText.setTypeface(Typeface.MONOSPACE);
        gutterText.setTextAlign(Paint.Align.RIGHT);
        updateGutter();

        addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (applyingHistory) return;
                pendingOld = s.subSequence(start, start + count).toString();
            }

            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (applyingHistory || suppress) return;
                pushEdit(new Edit(start, pendingOld, s.subSequence(start, start + count).toString()));
            }

            @Override public void afterTextChanged(Editable e) {
                handler.removeCallbacks(highlightTask);
                handler.postDelayed(highlightTask, 250);
                updateGutter();
                if (suppress) return;
                if (!marks.isEmpty()) marks.clear();       // i numeri di riga non sono più affidabili
                if (listener != null) listener.onChanged();
            }
        });
    }

    // ------------------------------------------------------------------ API

    public void setOnContentChanged(OnContentChanged l) {
        listener = l;
    }

    /** Carica un nuovo contenuto (azzera cronologia undo e marcature). */
    public void setContent(String text, String lang) {
        suppress = true;
        try {
            language = lang;
            undo.clear();
            redo.clear();
            marks.clear();
            setText(text);
            setSelection(0);
            scrollTo(0, 0);
        } finally {
            suppress = false;
        }
        handler.removeCallbacks(highlightTask);
        handler.post(highlightTask);
    }

    public void setEditorTextSize(float sp) {
        setTextSize(sp);
        updateGutter();
    }

    public void setMarks(Map<Integer, Integer> m) {
        marks.clear();
        if (m != null) marks.putAll(m);
        invalidate();
    }

    public void clearMarks() {
        marks.clear();
        invalidate();
    }

    // ------------------------------------------------------------ undo/redo

    private void pushEdit(Edit e) {
        redo.clear();
        if (!undo.isEmpty()) {
            Edit last = undo.get(undo.size() - 1);
            boolean typing = e.oldText.isEmpty() && e.newText.length() == 1
                    && last.oldText.isEmpty() && last.start + last.newText.length() == e.start
                    && !Character.isWhitespace(e.newText.charAt(0)) && last.newText.length() < 40
                    && !last.newText.endsWith("\n");
            if (typing) {
                undo.set(undo.size() - 1, new Edit(last.start, "", last.newText + e.newText));
                return;
            }
        }
        undo.add(e);
        if (undo.size() > 400) undo.remove(0);
    }

    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }

    public boolean undo() {
        if (undo.isEmpty()) return false;
        Edit e = undo.remove(undo.size() - 1);
        if (!applyHistory(e.start, e.newText.length(), e.oldText)) return false;
        redo.add(e);
        return true;
    }

    public boolean redo() {
        if (redo.isEmpty()) return false;
        Edit e = redo.remove(redo.size() - 1);
        if (!applyHistory(e.start, e.oldText.length(), e.newText)) return false;
        undo.add(e);
        return true;
    }

    private boolean applyHistory(int start, int removeLen, String insert) {
        applyingHistory = true;
        try {
            getText().replace(start, start + removeLen, insert);
            setSelection(Math.min(getText().length(), start + insert.length()));
            return true;
        } catch (IndexOutOfBoundsException ex) {
            undo.clear();                                   // cronologia incoerente: la si scarta
            redo.clear();
            return false;
        } finally {
            applyingHistory = false;
        }
    }

    // ----------------------------------------------------------- vai a linea

    public int lineCount() {
        String t = getText().toString();
        int n = 1;
        for (int i = 0; i < t.length(); i++) if (t.charAt(i) == '\n') n++;
        return n;
    }

    public void goToLine(int line) {
        String t = getText().toString();
        int idx = 0, cur = 1;
        while (cur < line) {
            int nl = t.indexOf('\n', idx);
            if (nl < 0) break;
            idx = nl + 1;
            cur++;
        }
        setSelection(idx);
        requestFocus();
        scrollToOffset(idx);
    }

    public void scrollToOffset(final int off) {
        Layout l = getLayout();
        if (l == null) {
            if (isAttachedToWindow()) post(new Runnable() {
                @Override public void run() { scrollToOffset(off); }
            });
            return;
        }
        int line = l.getLineForOffset(Math.min(off, getText().length()));
        int y = l.getLineTop(line) - getHeight() / 3;
        int maxY = Math.max(0, l.getHeight() + getExtendedPaddingTop() + getExtendedPaddingBottom() - getHeight());
        scrollTo(0, Math.max(0, Math.min(y, maxY)));
    }

    // -------------------------------------------------------- cerca/sostituisci

    private static int indexOf(String t, String q, int from, boolean cs) {
        for (int i = Math.max(0, from); i + q.length() <= t.length(); i++) {
            if (t.regionMatches(!cs, i, q, 0, q.length())) return i;
        }
        return -1;
    }

    private static int lastIndexOf(String t, String q, int from, boolean cs) {
        for (int i = Math.min(from, t.length() - q.length()); i >= 0; i--) {
            if (t.regionMatches(!cs, i, q, 0, q.length())) return i;
        }
        return -1;
    }

    /** Cerca la prossima/precedente occorrenza (con wrap). @return false se non trovata. */
    public boolean find(String q, boolean forward, boolean matchCase) {
        getText().removeSpan(findSpan);
        if (q == null || q.isEmpty()) return false;
        String t = getText().toString();
        int i;
        if (forward) {
            i = indexOf(t, q, getSelectionEnd(), matchCase);
            if (i < 0) i = indexOf(t, q, 0, matchCase);
        } else {
            i = lastIndexOf(t, q, getSelectionStart() - 1, matchCase);
            if (i < 0) i = lastIndexOf(t, q, t.length(), matchCase);
        }
        if (i < 0) return false;
        setSelection(i, i + q.length());
        getText().setSpan(findSpan, i, i + q.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        scrollToOffset(i);
        return true;
    }

    /** Sostituisce la selezione se coincide con la ricerca, poi passa alla successiva. */
    public boolean replaceCurrent(String q, String r, boolean matchCase) {
        int s = getSelectionStart(), e = getSelectionEnd();
        if (q.isEmpty()) return false;
        if (e - s == q.length() && getText().toString().regionMatches(!matchCase, s, q, 0, q.length())) {
            getText().removeSpan(findSpan);
            getText().replace(s, e, r);
            setSelection(s + r.length());
        }
        return find(q, true, matchCase);
    }

    /** Sostituisce tutto in un solo passo di undo. @return numero di sostituzioni. */
    public int replaceAll(String q, String r, boolean matchCase) {
        if (q == null || q.isEmpty()) return 0;
        String t = getText().toString();
        StringBuilder sb = new StringBuilder(t.length());
        int count = 0, i = 0;
        while (true) {
            int j = indexOf(t, q, i, matchCase);
            if (j < 0) break;
            sb.append(t, i, j).append(r);
            i = j + q.length();
            count++;
        }
        if (count == 0) return 0;
        sb.append(t, i, t.length());
        getText().removeSpan(findSpan);
        getText().replace(0, t.length(), sb.toString());
        return count;
    }

    public void insertAtCursor(String s) {
        int a = Math.max(0, getSelectionStart()), b = Math.max(0, getSelectionEnd());
        getText().replace(Math.min(a, b), Math.max(a, b), s);
    }

    // --------------------------------------------------------------- disegno

    private void updateGutter() {
        gutterText.setTextSize(getTextSize());
        int lines = Math.max(1, getLineCount());
        int digits = Math.max(3, String.valueOf(lines).length());
        int w = Math.round(gutterText.measureText("0") * digits) + Ui.dp(getContext(), 22);
        if (w != gutterWidth) {
            gutterWidth = w;
            setPadding(w + Ui.dp(getContext(), 6), Ui.dp(getContext(), 4), Ui.dp(getContext(), 8), Ui.dp(getContext(), 4));
        }
    }

    @Override protected void onDraw(Canvas c) {
        Layout l = getLayout();
        int sx = getScrollX(), sy = getScrollY();
        int top = getExtendedPaddingTop();
        int first = 0, last = -1;
        if (l != null) {
            first = l.getLineForVertical(sy);
            last = Math.min(l.getLineCount() - 1, l.getLineForVertical(sy + getHeight()));
            for (int i = first; i <= last; i++) {
                Integer m = marks.get(i + 1);
                if (m == null) continue;
                markPaint.setColor(m == ErrorAnalyzer.MARK_ERROR ? 0x66FF3B30
                        : m == ErrorAnalyzer.MARK_CAUSE ? 0x55FF9500 : 0x40FFD60A);
                c.drawRect(sx, top + l.getLineTop(i), sx + getWidth(), top + l.getLineBottom(i), markPaint);
            }
        }
        super.onDraw(c);
        if (l == null) return;

        c.drawRect(sx, sy, sx + gutterWidth, sy + getHeight(), gutterBg);
        int curLine = l.getLineForOffset(Math.max(0, getSelectionStart()));
        for (int i = first; i <= last; i++) {
            Integer m = marks.get(i + 1);
            gutterText.setColor(m != null && m == ErrorAnalyzer.MARK_ERROR ? 0xFFFF6B6B
                    : i == curLine ? 0xFFD7DAE0 : 0xFF6B7280);
            c.drawText(String.valueOf(i + 1), sx + gutterWidth - Ui.dp(getContext(), 8),
                    top + l.getLineBaseline(i), gutterText);
            if (m != null) {
                dotPaint.setColor(m == ErrorAnalyzer.MARK_ERROR ? 0xFFFF453A : 0xFFFF9F0A);
                float cy = top + (l.getLineTop(i) + l.getLineBottom(i)) / 2f;
                c.drawCircle(sx + Ui.dp(getContext(), 8), cy, Ui.dp(getContext(), 3.5f), dotPaint);
            }
        }
    }

    // --------------------------------------------------------- auto-indent

    /** Dopo Invio mantiene l'indentazione; in Python aggiunge 4 spazi dopo ':'. */
    private final class AutoIndentFilter implements InputFilter {
        @Override public CharSequence filter(CharSequence src, int start, int end, Spanned dest, int ds, int de) {
            if (end - start != 1 || src.charAt(start) != '\n' || applyingHistory) return null;
            int ls = ds;
            while (ls > 0 && dest.charAt(ls - 1) != '\n') ls--;
            int k = ls;
            while (k < ds && (dest.charAt(k) == ' ' || dest.charAt(k) == '\t')) k++;
            StringBuilder out = new StringBuilder("\n").append(dest, ls, k);
            int e = ds;
            while (e > ls && dest.charAt(e - 1) == ' ') e--;
            if (language.equals("python") && e > ls && dest.charAt(e - 1) == ':') out.append("    ");
            return out;
        }
    }
}
