package dev.pyide;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Analizza lo stderr di Python (traceback o SyntaxError) e produce:
 *  - tipo di errore (sintassi / runtime),
 *  - riga dell'errore,
 *  - righe collegate: catena di chiamate, eccezioni concatenate e
 *    "cause probabili" (ultime assegnazioni delle variabili usate nella riga che fallisce).
 * Classe Java pura (nessuna dipendenza Android): testabile con JUnit.
 */
public final class ErrorAnalyzer {

    public static final int MARK_ERROR = 1;     // riga dell'errore (rosso)
    public static final int MARK_CAUSE = 2;     // chiamata / eccezione collegata (arancio)
    public static final int MARK_PROBABLE = 3;  // causa probabile (giallo)

    public static final class Frame {
        public final File file;
        public final int line;
        public final String func;
        public final boolean inProject;

        Frame(File file, int line, String func, boolean inProject) {
            this.file = file;
            this.line = line;
            this.func = func;
            this.inProject = inProject;
        }
    }

    public static final class Report {
        public String type = "";
        public String message = "";
        public boolean syntax;
        public Frame errorFrame;
        public final List<Frame> callChain = new ArrayList<>();
        public final List<Frame> chained = new ArrayList<>();
        public final List<Frame> probable = new ArrayList<>();

        public String kindLabel() {
            return syntax ? "Errore di sintassi" : "Errore di runtime";
        }

        /** Mappa riga(1-based) -> tipo di marcatura, per il file indicato. */
        public Map<Integer, Integer> marksFor(File f) {
            Map<Integer, Integer> m = new TreeMap<>();
            if (f == null) return m;
            addMarks(m, chained, MARK_CAUSE, f);
            addMarks(m, callChain, MARK_CAUSE, f);
            addMarks(m, probable, MARK_PROBABLE, f);
            if (errorFrame != null && same(errorFrame.file, f)) m.put(errorFrame.line, MARK_ERROR);
            return m;
        }

        /** Tutti i file coinvolti (per aprire quello dell'errore). */
        public List<Frame> allLocations() {
            List<Frame> all = new ArrayList<>();
            if (errorFrame != null) all.add(errorFrame);
            all.addAll(callChain);
            all.addAll(chained);
            all.addAll(probable);
            return all;
        }

        private static void addMarks(Map<Integer, Integer> m, List<Frame> frames, int kind, File f) {
            for (Frame fr : frames) {
                if (same(fr.file, f) && !m.containsKey(fr.line)) m.put(fr.line, kind);
            }
        }
    }

    private static final Pattern FRAME =
            Pattern.compile("^\\s*File \"(.+?)\", line (\\d+)(?:, in (.+))?\\s*$");
    private static final Pattern EXC = Pattern.compile("^([A-Za-z_][\\w.]*)(?::\\s?(.*))?$");
    private static final String[] CHAIN_MARKERS = {
            "The above exception was the direct cause of the following exception:",
            "During handling of the above exception, another exception occurred:"
    };
    private static final Set<String> SKIP_IDENTS = new HashSet<>(Arrays.asList(
            "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class",
            "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global",
            "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise",
            "return", "try", "while", "with", "yield", "print", "len", "range", "int", "str",
            "float", "list", "dict", "set", "tuple", "bool", "open", "input", "type", "self"));

    private ErrorAnalyzer() {}

    /** @return null se lo stderr non contiene un errore Python riconoscibile. */
    public static Report analyze(String stderr, File projectDir) {
        if (stderr == null) return null;
        List<List<String>> blocks = splitBlocks(stderr);

        Report r = new Report();
        File root = canon(projectDir);

        List<String> last = null;
        for (int i = blocks.size() - 1; i >= 0; i--) {
            if (hasFrameOrExc(blocks.get(i))) { last = blocks.get(i); break; }
        }
        if (last == null) return null;

        // eccezioni concatenate (blocchi precedenti): sono "cause" dell'errore finale
        int lastIdx = blocks.indexOf(last);
        for (int i = 0; i < lastIdx; i++) {
            for (Frame f : parseFrames(blocks.get(i), root)) if (f.inProject) r.chained.add(f);
        }

        List<Frame> frames = parseFrames(last, root);
        parseExceptionLine(last, r);
        if (r.type.isEmpty() && frames.isEmpty()) return null;
        r.syntax = r.type.endsWith("SyntaxError") || r.type.endsWith("IndentationError")
                || r.type.equals("TabError");

        Frame err = null;
        for (int i = frames.size() - 1; i >= 0; i--) {
            if (frames.get(i).inProject) { err = frames.get(i); break; }
        }
        if (err == null && !frames.isEmpty()) err = frames.get(frames.size() - 1);
        r.errorFrame = err;
        for (Frame f : frames) if (f.inProject && f != err) r.callChain.add(f);

        if (err != null && err.inProject && !r.syntax) findProbableCauses(err, r);
        return r;
    }

    // ---------------------------------------------------------------- parsing

    private static List<List<String>> splitBlocks(String text) {
        List<List<String>> blocks = new ArrayList<>();
        List<String> cur = new ArrayList<>();
        for (String line : text.split("\r?\n")) {
            String t = line.trim();
            boolean marker = false;
            for (String m : CHAIN_MARKERS) if (t.equals(m)) marker = true;
            if (marker) {
                blocks.add(cur);
                cur = new ArrayList<>();
            } else {
                cur.add(line);
            }
        }
        blocks.add(cur);
        return blocks;
    }

    private static boolean hasFrameOrExc(List<String> block) {
        for (String l : block) if (FRAME.matcher(l).matches()) return true;
        return false;
    }

    private static List<Frame> parseFrames(List<String> block, File root) {
        List<Frame> out = new ArrayList<>();
        for (String l : block) {
            Matcher m = FRAME.matcher(l);
            if (!m.matches()) continue;
            String path = m.group(1);
            if (path.startsWith("<")) continue;           // <stdin>, <string>, <frozen ...>
            File f = new File(path);
            if (!f.isAbsolute()) f = new File(root, path);
            f = canon(f);
            if (!isInside(root, f)) f = remapForeignPath(path, root, f);   // es. percorsi visti da Termux
            int line = Integer.parseInt(m.group(2));
            out.add(new Frame(f, line, m.group(3), isInside(root, f)));
        }
        return out;
    }

    /** Se lo script gira in un altro ambiente (Termux) il percorso può avere un prefisso diverso:
     *  si riconosce dalla cartella del progetto ("/NomeProgetto/") e si rimappa sul file locale. */
    private static File remapForeignPath(String path, File root, File fallback) {
        String marker = "/" + root.getName() + "/";
        int i = path.lastIndexOf(marker);
        if (i < 0) return fallback;
        File cand = new File(root, path.substring(i + marker.length()));
        return cand.exists() ? canon(cand) : fallback;
    }

    private static void parseExceptionLine(List<String> block, Report r) {
        for (int i = block.size() - 1; i >= 0; i--) {
            String l = block.get(i);
            if (l.isEmpty() || Character.isWhitespace(l.charAt(0))) continue;
            if (l.startsWith("Traceback")) continue;
            Matcher m = EXC.matcher(l.trim());
            if (m.matches()) {
                r.type = m.group(1);
                r.message = m.group(2) == null ? "" : m.group(2).trim();
                return;
            }
        }
    }

    // ------------------------------------------------------- cause probabili

    private static final Pattern IDENT = Pattern.compile("(?<![\\w.])[A-Za-z_]\\w*");

    private static void findProbableCauses(Frame err, Report r) {
        List<String> lines = readLines(err.file);
        if (lines == null || err.line < 1 || err.line > lines.size()) return;

        String code = lines.get(err.line - 1);
        int hash = code.indexOf('#');
        if (hash >= 0) code = code.substring(0, hash);
        code = code.replaceAll("\"[^\"]*\"|'[^']*'", "\"\"");

        // in "y = f(x)" la y è il bersaglio, non una causa: si analizza solo la parte destra
        String scan = code;
        Matcher asg = Pattern.compile("^\\s*[\\w\\s,.\\[\\]()*]+?(?:[-+*/%@|&^]|//|\\*\\*)?=(?!=)(.*)$").matcher(code);
        if (asg.matches()) scan = asg.group(1);

        Set<String> idents = new java.util.LinkedHashSet<>();
        Matcher m = IDENT.matcher(scan);
        while (m.find()) if (!SKIP_IDENTS.contains(m.group())) idents.add(m.group());

        int errIndent = indent(lines.get(err.line - 1));
        Set<Integer> seen = new HashSet<>();
        for (String id : idents) {
            Pattern defPat = definitionPattern(id);
            int stop = Math.max(0, err.line - 1 - 400);
            for (int i = err.line - 2; i >= stop; i--) {
                String l = lines.get(i);
                if (defPat.matcher(l).find()) {
                    if (seen.add(i + 1)) r.probable.add(new Frame(err.file, i + 1, id, true));
                    break;
                }
                String tl = l.trim();
                if ((tl.startsWith("def ") || tl.startsWith("class ")) && indent(l) < errIndent) break;
            }
            if (r.probable.size() >= 4) break;
        }
    }

    private static Pattern definitionPattern(String id) {
        String q = Pattern.quote(id);
        return Pattern.compile(
                "^\\s*[\\w\\s,()\\[\\]*.]*\\b" + q + "\\b[\\w\\s,()\\[\\]*.]*(?:[-+*/%@|&^]|//|\\*\\*|:)?=(?!=)"
                        + "|^\\s*(?:async\\s+)?for\\s+[\\w\\s,()]*\\b" + q + "\\b[\\w\\s,()]*\\sin\\b"
                        + "|^\\s*(?:async\\s+)?def\\s+" + q + "\\b"
                        + "|^\\s*(?:async\\s+)?def\\s+\\w+\\s*\\(.*\\b" + q + "\\b"
                        + "|^\\s*class\\s+" + q + "\\b"
                        + "|\\bas\\s+" + q + "\\b"
                        + "|^\\s*import\\s+" + q + "\\b"
                        + "|^\\s*from\\s+\\S+\\s+import\\s+.*\\b" + q + "\\b");
    }

    // ------------------------------------------------------------- utilità

    private static int indent(String s) {
        int i = 0;
        while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) i++;
        return i;
    }

    private static List<String> readLines(File f) {
        List<String> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String l;
            while ((l = br.readLine()) != null && out.size() < 50000) out.add(l);
            return out;
        } catch (IOException e) {
            return null;
        }
    }

    private static File canon(File f) {
        try {
            return f.getCanonicalFile();
        } catch (IOException e) {
            return f.getAbsoluteFile();
        }
    }

    private static boolean isInside(File root, File f) {
        return f.getPath().startsWith(root.getPath() + File.separator);
    }

    private static boolean same(File a, File b) {
        return canon(a).equals(canon(b));
    }
}
