package dev.pyide;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

/**
 * Ponte verso Termux tramite l'intent RUN_COMMAND (richiede: Termux installato da F-Droid/GitHub,
 * allow-external-apps=true in ~/.termux/termux.properties, permesso com.termux.permission.RUN_COMMAND
 * concesso a questa app, accesso allo storage condiviso per entrambe le app).
 */
final class TermuxBridge {
    static final String PKG = "com.termux";
    static final String PERM = "com.termux.permission.RUN_COMMAND";
    static final String HOME = "/data/data/com.termux/files/home";
    static final String BASH = "/data/data/com.termux/files/usr/bin/bash";
    static final String TUR_INDEX = "https://termux-user-repository.github.io/pypi/";

    /** Comandi da incollare in Termux la prima volta. */
    static final String SETUP_COMMANDS =
            "mkdir -p ~/.termux && (grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null"
            + " || echo 'allow-external-apps=true' >> ~/.termux/termux.properties)\n"
            + "termux-setup-storage\n"
            + "pkg update -y && pkg install -y python python-pip\n";

    private final Context ctx;

    TermuxBridge(Context c) {
        ctx = c.getApplicationContext();
    }

    boolean isInstalled() {
        try {
            ctx.getPackageManager().getPackageInfo(PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    boolean hasPermission() {
        return ctx.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED;
    }

    /** Quota una stringa per bash (apici singoli). */
    static String q(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    /** Esegue uno script bash senza interfaccia. @return messaggio d'errore o null se inviato. */
    String runBackground(String script, String workdir) {
        return send(script, workdir, true);
    }

    /** Apre una sessione visibile in Termux. */
    String runForeground(String script, String workdir) {
        return send(script, workdir, false);
    }

    private String send(String script, String workdir, boolean background) {
        if (!isInstalled()) return "Termux non è installato.";
        Intent i = new Intent("com.termux.RUN_COMMAND");
        i.setClassName(PKG, "com.termux.app.RunCommandService");
        i.putExtra("com.termux.RUN_COMMAND_PATH", BASH);
        i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-c", script});
        i.putExtra("com.termux.RUN_COMMAND_WORKDIR", workdir);
        i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", background);
        i.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0");
        try {
            ComponentName cn = ctx.startService(i);
            return cn == null ? "Termux non ha accettato il comando (servizio non trovato)." : null;
        } catch (SecurityException e) {
            return "Permesso \"Esegui comandi in Termux\" non concesso a PyIDE.";
        } catch (RuntimeException e) {
            return "Impossibile contattare Termux: " + e.getMessage();
        }
    }

    void openApp() {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(PKG);
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        }
    }
}
