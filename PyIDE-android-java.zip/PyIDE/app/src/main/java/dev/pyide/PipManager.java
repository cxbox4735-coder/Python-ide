package dev.pyide;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * Gestore delle estensioni.
 *  - Automatico: "python -m pip install <nome>" in un processo separato, con log in tempo reale.
 *  - Manuale: importa un .whl, lo valida (WheelValidator) e solo se valido lo installa.
 * Tutto su thread di background; i callback arrivano sul main thread.
 */
final class PipManager {
    interface Callback {
        void onLog(String line);
        void onDone(boolean ok, String message);
    }

    private static final Pattern SPEC = Pattern.compile(
            "^[A-Za-z0-9][A-Za-z0-9._\\-]*(\\[[A-Za-z0-9,._\\-]+\\])?((==|>=|<=|~=|!=|<|>)[A-Za-z0-9.*+!_\\-]+)*$");
    private static final long MIN_FREE_BYTES = 300L * 1024 * 1024;

    private final Context ctx;
    private final PythonEnv env;
    private final Prefs prefs;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();   // un'installazione alla volta
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile Process current;

    PipManager(Context ctx, PythonEnv env, Prefs prefs) {
        this.ctx = ctx.getApplicationContext();
        this.env = env;
        this.prefs = prefs;
    }

    // ------------------------------------------------------------ automatica

    /** @return elenco di specifiche valide, oppure null se qualcosa non è valido (anti-injection). */
    static List<String> parseSpecs(String input) {
        List<String> specs = new ArrayList<>();
        for (String s : input.trim().split("\\s+")) if (!s.isEmpty()) specs.add(s);
        if (specs.isEmpty() || specs.size() > 20) return null;
        for (String s : specs) if (!SPEC.matcher(s).matches()) return null;
        return specs;
    }

    void install(final String input, final Callback cb) {
        final List<String> specs = new ArrayList<>();
        for (String s : input.trim().split("\\s+")) if (!s.isEmpty()) specs.add(s);
        if (specs.isEmpty() || specs.size() > 20) {
            cb.onDone(false, "Inserisci da 1 a 20 nomi di pacchetto, separati da spazio.");
            return;
        }
        for (String s : specs) {
            if (!SPEC.matcher(s).matches()) {
                cb.onDone(false, "Nome non valido: \"" + s + "\". Esempi: torch, pandas==2.2.0, requests[socks]");
                return;
            }
        }
        pool.execute(new Runnable() {
            @Override public void run() {
                if (env.sitePackages.getUsableSpace() < MIN_FREE_BYTES) {
                    done(cb, false, "Spazio insufficiente (servono almeno 300 MB liberi).");
                    return;
                }
                List<String> args = new ArrayList<>(Arrays.asList("install", "--upgrade", "--prefer-binary",
                        "--target", env.sitePackages.getAbsolutePath()));
                String extra = prefs.extraIndex();
                if (extra.startsWith("https://")) { args.add("--extra-index-url"); args.add(extra); }
                args.addAll(specs);
                StringBuilder log = new StringBuilder();
                int rc = runPip(args, cb, log);
                if (rc == 0) done(cb, true, "Installato: " + android.text.TextUtils.join(" ", specs));
                else done(cb, false, explain(log.toString()));
            }
        });
    }

    /** Traduce gli errori tipici di pip in spiegazioni comprensibili. */
    static String explain(String log) {
        if (log.contains("No matching distribution found") || log.contains("Could not find a version")) {
            return "Nessuna versione compatibile con Android per questo dispositivo. Il pacchetto potrebbe non "
                    + "avere una wheel Android (succede con torch e tensorflow) o richiedere un'altra versione di "
                    + "Python. Prova a indicare una versione, o imposta un indice pip con wheel Android.";
        }
        if (log.contains("Failed building wheel") || log.contains("error: command") || log.contains("subprocess-exited-with-error")) {
            return "Il pacchetto richiede compilazione nativa (compilatore C/Rust) non disponibile sul dispositivo. "
                    + "Serve una wheel precompilata per Android.";
        }
        if (log.contains("Connection") || log.contains("Temporary failure") || log.contains("timed out")) {
            return "Errore di rete durante il download. Controlla la connessione e riprova.";
        }
        if (log.contains("No space left")) return "Spazio esaurito sul dispositivo.";
        if (log.contains("No module named pip") || log.contains("ensurepip")) {
            return "pip non è incluso nel runtime Python. Aggiungi ensurepip/pip alla stdlib (vedi README).";
        }
        return "Installazione fallita. Controlla il log per i dettagli.";
    }

    // --------------------------------------------------------------- manuale

    void installWheel(final Uri uri, final Callback cb) {
        pool.execute(new Runnable() {
            @Override public void run() {
                File tmp = null;
                try {
                    String name = displayName(uri);
                    if (!name.toLowerCase().endsWith(".whl")) {
                        done(cb, false, "Il file \"" + name + "\" non è una wheel (.whl).");
                        return;
                    }
                    File dir = new File(ctx.getCacheDir(), "imports");
                    dir.mkdirs();
                    tmp = new File(dir, FileOps.validName(name));
                    log(cb, "Copia del file in corso...");
                    copy(uri, tmp);

                    log(cb, "Validazione della wheel...");
                    WheelValidator.Result r = WheelValidator.validate(tmp, PythonEnv.PY_TAG, env.deviceAbis());
                    if (!r.ok) {
                        done(cb, false, r.message);
                        return;
                    }
                    log(cb, r.message);
                    if (!r.requires.isEmpty()) log(cb, "Dipendenze dichiarate: " + r.requires
                            + "\n(l'installazione manuale non le scarica: usa la modalità automatica se mancano)");

                    StringBuilder out = new StringBuilder();
                    int rc = runPip(Arrays.asList("install", "--no-deps", "--no-index", "--upgrade",
                            "--target", env.sitePackages.getAbsolutePath(), tmp.getAbsolutePath()), cb, out);
                    if (rc != 0) {
                        done(cb, false, "Installazione fallita: " + explain(out.toString()));
                        return;
                    }
                    File keep = new File(env.wheelhouse, tmp.getName());
                    copyFile(tmp, keep);                              // salvata nell'ambiente di lavoro
                    done(cb, true, "Installato: " + r.dist + " " + r.version);
                } catch (IOException e) {
                    done(cb, false, "Errore: " + e.getMessage());
                } finally {
                    if (tmp != null) tmp.delete();
                }
            }
        });
    }

    void uninstall(final String name, final Callback cb) {
        pool.execute(new Runnable() {
            @Override public void run() {
                // pip uninstall non supporta --target: si rimuovono dist-info e cartelle elencate in RECORD
                try {
                    File[] infos = env.sitePackages.listFiles();
                    boolean found = false;
                    if (infos != null) for (File d : infos) {
                        String n = d.getName();
                        if (n.endsWith(".dist-info") && n.toLowerCase().replace('_', '-').startsWith(name.toLowerCase().replace('_', '-') + "-")) {
                            File rec = new File(d, "RECORD");
                            if (rec.exists()) removeRecorded(rec);
                            FileOps.deleteQuiet(d);
                            found = true;
                        }
                    }
                    done(cb, found, found ? "Rimosso: " + name : "Pacchetto non trovato: " + name);
                } catch (IOException e) {
                    done(cb, false, "Errore: " + e.getMessage());
                }
            }
        });
    }

    private void removeRecorded(File record) throws IOException {
        File base = env.sitePackages;
        try (BufferedReader br = new BufferedReader(new java.io.FileReader(record))) {
            String l;
            while ((l = br.readLine()) != null) {
                String rel = l.split(",")[0];
                File f = new File(base, rel);
                if (FileOps.isInside(base, f) && !f.equals(base)) f.delete();
            }
        }
    }

    List<String> installed() {
        List<String> out = new ArrayList<>();
        File[] kids = env.sitePackages.listFiles();
        if (kids != null) for (File k : kids) {
            if (k.getName().endsWith(".dist-info")) {
                String n = k.getName().substring(0, k.getName().length() - 10);
                int i = n.lastIndexOf('-');
                out.add(i > 0 ? n.substring(0, i) + " " + n.substring(i + 1) : n);
            }
        }
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    void cancel() {
        Process p = current;
        if (p != null) p.destroy();
    }

    // ------------------------------------------------------------- interni

    private int runPip(List<String> args, final Callback cb, StringBuilder logOut) {
        List<String> cmd = new ArrayList<>();
        cmd.add(env.executable().getAbsolutePath());
        cmd.addAll(Arrays.asList("-m", "pip"));
        cmd.addAll(args);
        cmd.add("--progress-bar");
        cmd.add("off");
        try {
            env.ensureReady();
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            env.applyEnv(pb.environment());
            Process p = pb.start();
            current = p;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (logOut.length() < 200_000) logOut.append(line).append('\n');
                    log(cb, line);
                }
            }
            return p.waitFor();
        } catch (Exception e) {
            log(cb, "Errore: " + e.getMessage());
            logOut.append(e.getMessage());
            return -1;
        } finally {
            current = null;
        }
    }

    private void log(final Callback cb, final String s) {
        ui.post(new Runnable() { @Override public void run() { cb.onLog(s); } });
    }

    private void done(final Callback cb, final boolean ok, final String msg) {
        ui.post(new Runnable() { @Override public void run() { cb.onDone(ok, msg); } });
    }

    private String displayName(Uri uri) {
        String name = "package.whl";
        ContentResolver cr = ctx.getContentResolver();
        try (Cursor c = cr.query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && c.getString(i) != null) name = c.getString(i);
            }
        }
        return name.replace('/', '_');
    }

    private void copy(Uri uri, File dst) throws IOException {
        try (InputStream in = ctx.getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(dst)) {
            if (in == null) throw new IOException("Impossibile aprire il file selezionato");
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    private static void copyFile(File src, File dst) throws IOException {
        try (java.io.FileInputStream in = new java.io.FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }
}
