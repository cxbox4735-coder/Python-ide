package dev.pyide;

import java.io.File;

/** Backend di esecuzione degli script: runtime incorporato (PythonRunner) oppure Termux (TermuxRunner). */
interface ScriptRunner {
    interface Listener {
        void onStart();
        void onOutput(String text, boolean isError);
        void onFinish(int exitCode, long millis, boolean stoppedByUser);
    }

    boolean isRunning();

    void run(File workDir, File script, Listener l);

    void stop();

    /** @return false se il backend non supporta stdin interattivo. */
    boolean sendInput(String line);
}
