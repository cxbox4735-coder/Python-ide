package dev.pyide;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import java.util.function.Consumer;

/** Piccole utilità per dialoghi e dimensioni. */
final class Ui {
    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static void toast(Context c, String msg) {
        Toast.makeText(c, msg, Toast.LENGTH_SHORT).show();
    }

    static void prompt(Activity a, String title, String initial, final Consumer<String> ok) {
        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setText(initial);
        et.setSelection(et.getText().length());
        AlertDialog.Builder b = new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert);
        b.setTitle(title).setView(et).setNegativeButton("Annulla", null)
                .setPositiveButton("OK", (d, w) -> ok.accept(et.getText().toString())).show();
    }

    static void confirm(Activity a, String title, String msg, final Runnable yes) {
        new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(title).setMessage(msg).setNegativeButton("Annulla", null)
                .setPositiveButton("Conferma", (d, w) -> yes.run()).show();
    }
}
