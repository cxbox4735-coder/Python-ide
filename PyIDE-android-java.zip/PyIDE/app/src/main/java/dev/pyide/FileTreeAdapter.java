package dev.pyide;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Albero dei file del progetto nella sidebar (lista piatta con indentazione e cartelle espandibili). */
final class FileTreeAdapter extends BaseAdapter {
    static final class Node {
        final File file;
        final int depth;
        Node(File f, int d) { file = f; depth = d; }
    }

    private final Context ctx;
    private final List<Node> nodes = new ArrayList<>();
    private final Set<String> expanded = new HashSet<>();
    private File root, entry, selected;

    FileTreeAdapter(Context c) {
        ctx = c;
    }

    void reload(File root, File entry, File selected) {
        if (this.root == null || !this.root.equals(root)) expanded.clear();
        this.root = root;
        this.entry = entry;
        this.selected = selected;
        nodes.clear();
        if (root != null) add(root, 0);
        notifyDataSetChanged();
    }

    void toggle(File dir) {
        String p = dir.getAbsolutePath();
        if (!expanded.remove(p)) expanded.add(p);
        reload(root, entry, selected);
    }

    void expand(File dir) {
        expanded.add(dir.getAbsolutePath());
    }

    private void add(File dir, int depth) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        Arrays.sort(kids, new Comparator<File>() {
            @Override public int compare(File a, File b) {
                if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        for (File k : kids) {
            if (k.getName().startsWith(".pyide") || k.getName().endsWith(".tmp")) continue;
            nodes.add(new Node(k, depth));
            if (k.isDirectory() && expanded.contains(k.getAbsolutePath())) add(k, depth + 1);
        }
    }

    @Override public int getCount() { return nodes.size(); }
    @Override public Node getItem(int i) { return nodes.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int i, View v, ViewGroup parent) {
        TextView t = v instanceof TextView ? (TextView) v : new TextView(ctx);
        Node n = nodes.get(i);
        int pad = Ui.dp(ctx, 12);
        t.setPadding(pad + n.depth * Ui.dp(ctx, 16), Ui.dp(ctx, 10), pad, Ui.dp(ctx, 10));
        t.setTextSize(14);
        t.setSingleLine(true);
        boolean isEntry = entry != null && n.file.equals(entry);
        String prefix = n.file.isDirectory() ? (expanded.contains(n.file.getAbsolutePath()) ? "▾ 📁 " : "▸ 📁 ")
                : (isEntry ? "▶ " : "   ");
        t.setText(prefix + n.file.getName() + (isEntry ? "   (entry point)" : ""));
        t.setTextColor(isEntry ? 0xFF4CD964 : 0xFFD7DAE0);
        t.setBackgroundColor(n.file.equals(selected) ? 0xFF35383D : 0x00000000);
        return t;
    }
}
