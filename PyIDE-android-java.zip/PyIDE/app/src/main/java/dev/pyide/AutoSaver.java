package dev.pyide;

import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Salvataggio asincrono con coalescenza: ad ogni modifica si accoda un salvataggio, ma se nel
 * frattempo ne arrivano altri per lo stesso file viene scritta solo l'ultima versione.
 * La scrittura è atomica (file temporaneo + rename). Mai sul thread UI.
 */
final class AutoSaver {
    interface Done {
        void onSaved(File f, boolean ok, String error);
    }

    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<String, String> pending = new ConcurrentHashMap<>();

    void submit(final File f, String content, final Done cb) {
        final String path = f.getAbsolutePath();
        pending.put(path, content);
        ex.execute(new Runnable() {
            @Override public void run() {
                String c = pending.remove(path);
                if (c == null) return;                       // già scritto da un task successivo
                String err = null;
                try {
                    write(f, c);
                } catch (IOException e) {
                    err = e.getMessage();
                }
                final String fe = err;
                if (cb != null) ui.post(new Runnable() {
                    @Override public void run() { cb.onSaved(f, fe == null, fe); }
                });
            }
        });
    }

    boolean hasPending(File f) {
        return pending.containsKey(f.getAbsolutePath());
    }

    private static void write(File f, String content) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        ProjectManager.write(tmp, content);
        if (!tmp.renameTo(f)) {                              // fallback se rename non è permesso
            ProjectManager.write(f, content);
            tmp.delete();
        }
    }
}
