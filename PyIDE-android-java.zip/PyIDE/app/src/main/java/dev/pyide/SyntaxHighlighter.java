package dev.pyide;

import android.text.Editable;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Evidenziazione sintassi a regex per Python, JSON, HTML/XML, CSS e JavaScript. */
final class SyntaxHighlighter {
    static final class Span extends ForegroundColorSpan {
        Span(int c) { super(c); }
    }

    private static final int KEYWORD = 0xFFC678DD, BUILTIN = 0xFF61AFEF, STRING = 0xFF98C379,
            NUMBER = 0xFFD19A66, COMMENT = 0xFF7F848E, TAG = 0xFFE06C75, ATTR = 0xFFE5C07B;
    private static final int MAX_CHARS = 250_000;     // oltre: niente colori (protegge CPU/RAM)

    private static final class Rule {
        final Pattern p;
        final int[] colors;                          // colors[g] != 0 -> colora il gruppo g
        Rule(String regex, int... colors) {
            this.p = Pattern.compile(regex);
            this.colors = colors;
        }
    }

    private static final Map<String, List<Rule>> RULES = new HashMap<>();

    static {
        List<Rule> py = new ArrayList<>();
        py.add(new Rule("\\b(?:False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield|match|case)\\b", KEYWORD));
        py.add(new Rule("\\b(?:print|len|range|int|str|float|list|dict|set|tuple|bool|open|input|type|isinstance|enumerate|zip|map|filter|sum|min|max|abs|sorted|reversed|self|super)\\b", BUILTIN));
        py.add(new Rule("(?m)^[ \\t]*@[\\w.]+", ATTR));
        py.add(new Rule("\\b0[xX][0-9a-fA-F]+\\b|\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b", NUMBER));
        py.add(new Rule("(\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*')|(#.*)", 0, STRING, COMMENT));
        RULES.put("python", py);

        List<Rule> json = new ArrayList<>();
        json.add(new Rule("\\b(?:true|false|null)\\b", KEYWORD));
        json.add(new Rule("-?\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b", NUMBER));
        json.add(new Rule("\"(?:\\\\.|[^\"\\\\\\n])*\"", STRING));
        json.add(new Rule("\"(?:\\\\.|[^\"\\\\\\n])*\"(?=\\s*:)", ATTR));
        RULES.put("json", json);

        List<Rule> html = new ArrayList<>();
        html.add(new Rule("</?[A-Za-z][\\w:-]*|/?>", TAG));
        html.add(new Rule("\\s[\\w:-]+(?==)", ATTR));
        html.add(new Rule("\"[^\"]*\"|'[^']*'", STRING));
        html.add(new Rule("<!--[\\s\\S]*?-->", COMMENT));
        RULES.put("html", html);

        List<Rule> css = new ArrayList<>();
        css.add(new Rule("[\\w-]+(?=\\s*:)", ATTR));
        css.add(new Rule("#[0-9a-fA-F]{3,8}\\b|-?\\d+(?:\\.\\d+)?(?:px|em|rem|%|vh|vw|s|ms)?", NUMBER));
        css.add(new Rule("\"[^\"]*\"|'[^']*'", STRING));
        css.add(new Rule("/\\*[\\s\\S]*?\\*/", COMMENT));
        RULES.put("css", css);

        List<Rule> js = new ArrayList<>();
        js.add(new Rule("\\b(?:const|let|var|function|return|if|else|for|while|class|new|this|import|export|from|async|await|try|catch|throw|true|false|null|undefined)\\b", KEYWORD));
        js.add(new Rule("\\b\\d+(?:\\.\\d+)?\\b", NUMBER));
        js.add(new Rule("(\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'|`[^`]*`)|(//.*|/\\*[\\s\\S]*?\\*/)", 0, STRING, COMMENT));
        RULES.put("js", js);
    }

    /** Linguaggio dall'estensione del file. */
    static String langFor(String filename) {
        String n = filename.toLowerCase();
        if (n.endsWith(".py") || n.endsWith(".pyw")) return "python";
        if (n.endsWith(".json")) return "json";
        if (n.endsWith(".html") || n.endsWith(".htm") || n.endsWith(".xml")) return "html";
        if (n.endsWith(".css")) return "css";
        if (n.endsWith(".js")) return "js";
        return "text";
    }

    static void apply(Editable e, String lang) {
        for (Span s : e.getSpans(0, e.length(), Span.class)) e.removeSpan(s);
        List<Rule> rules = RULES.get(lang);
        if (rules == null || e.length() > MAX_CHARS) return;
        String text = e.toString();
        for (Rule r : rules) {
            Matcher m = r.p.matcher(text);
            while (m.find()) {
                for (int g = 0; g < r.colors.length; g++) {
                    if (r.colors[g] != 0 && m.start(g) >= 0 && m.end(g) > m.start(g)) {
                        e.setSpan(new Span(r.colors[g]), m.start(g), m.end(g), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                }
            }
        }
    }
}
