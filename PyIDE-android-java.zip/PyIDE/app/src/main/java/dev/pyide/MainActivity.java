package dev.pyide;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.Build;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Schermata principale: toolbar + editor + log + sidebar (file manager, terminale, PIP, impostazioni).
 * Regola d'oro: sul thread UI solo disegno e input; I/O, Python, pip e terminale girano altrove.
 */
public class MainActivity extends Activity {
    private static final int REQ_WHEEL = 42;
    private static final int C_OUT = 0xFFD7DAE0, C_ERR = 0xFFFF6B6B, C_INFO = 0xFF7AA2F7,
            C_OK = 0xFF4CD964, C_WARN = 0xFFFF9F0A;

    private Prefs prefs;
    private ProjectManager projects;
    private PythonEnv pyEnv;
    private PythonRunner embedded;
    private TermuxRunner termuxRunner;
    private TermuxBridge termuxBridge;
    private boolean sharedWanted;
    private PipManager pip;
    private TerminalSession terminal;
    private AutoSaver saver;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private File projectDir, currentFile;
    private boolean dirty, sidebarOpen, keyboardVisible;
    private int editVersion, openToken;
    private ErrorAnalyzer.Report pendingReport;
    private final StringBuilder stderrBuf = new StringBuilder();
    private ToolDialogs.PipDialog pipDialog;

    private CodeEditText editor;
    private TextView tvTitle, tvLog, tvProject, tvEntry;
    private ScrollView logScroll;
    private View sidebar, scrim, findBar, logPanel, logBody, extraKeys;
    private Button fab, btnLogStop;
    private EditText etFind, etReplace, etStdin;
    private CheckBox cbCase;
    private FileTreeAdapter tree;

    // ============================================================= ciclo di vita

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        prefs = new Prefs(this);
        pyEnv = new PythonEnv(this);
        termuxBridge = new TermuxBridge(this);
        embedded = new PythonRunner(pyEnv);
        termuxRunner = new TermuxRunner(termuxBridge);
        initProjects();
        pip = new PipManager(this, pyEnv, prefs);
        terminal = new TerminalSession(pyEnv);
        saver = new AutoSaver();

        bindViews();
        setupToolbar();
        setupFindBar();
        setupSidebar();
        setupLog();
        setupExtraKeys();
        setupKeyboardWatcher();
        applyPrefs();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }

        File last = projects.dir(prefs.lastProject());
        if (!prefs.lastProject().isEmpty() && last.isDirectory()) {
            openProject(last);
        } else if (!projects.list().isEmpty()) {
            openProject(projects.dir(projects.list().get(0)));
        } else {
            createAndOpenProject("MioProgetto");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // permesso "tutti i file" concesso mentre l'app era in secondo piano: passa alla cartella condivisa
        if (sharedWanted && !projects.isShared() && hasAllFiles()) {
            initProjects();
            List<String> l = projects.list();
            if (l.isEmpty()) createAndOpenProject("MioProgetto");
            else openProject(projects.dir(l.get(0)));
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (dirty && prefs.autosave()) saveCurrent(null);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        embedded.stop();                     // nessun processo orfano (i job Termux restano attivi)
        terminal.stop();
        RunnerService.stop(this);
    }

    @Override public void onBackPressed() {
        if (sidebarOpen) toggleSidebar(false);
        else if (findBar.getVisibility() == View.VISIBLE) findBar.setVisibility(View.GONE);
        else super.onBackPressed();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_WHEEL && res == RESULT_OK && data != null && data.getData() != null && pipDialog != null) {
            pipDialog.onWheelPicked(data.getData());
        }
    }

    // ================================================================= setup UI

    private void bindViews() {
        editor = findViewById(R.id.editor);
        tvTitle = findViewById(R.id.tvTitle);
        tvLog = findViewById(R.id.tvLog);
        tvProject = findViewById(R.id.tvProject);
        tvEntry = findViewById(R.id.tvEntry);
        logScroll = findViewById(R.id.logScroll);
        sidebar = findViewById(R.id.sidebar);
        scrim = findViewById(R.id.scrim);
        findBar = findViewById(R.id.findBar);
        logPanel = findViewById(R.id.logPanel);
        logBody = findViewById(R.id.logBody);
        extraKeys = findViewById(R.id.extraKeys);
        fab = findViewById(R.id.fabRun);
        btnLogStop = findViewById(R.id.btnLogStop);
        etFind = findViewById(R.id.etFind);
        etReplace = findViewById(R.id.etReplace);
        etStdin = findViewById(R.id.etStdin);
        cbCase = findViewById(R.id.cbCase);
    }

    private void setupToolbar() {
        // ---- salvataggio / autosalvataggio: ogni modifica passa da qui
        editor.setOnContentChanged(() -> {
            if (currentFile == null) return;
            editVersion++;
            dirty = true;
            if (prefs.autosave()) saveCurrent(null);      // asincrono e coalescente
            else updateTitle();
        });

        findViewById(R.id.btnMenu).setOnClickListener(v -> toggleSidebar(!sidebarOpen));
        findViewById(R.id.btnUndo).setOnClickListener(v -> { if (!editor.undo()) Ui.toast(this, "Niente da annullare"); });
        findViewById(R.id.btnRedo).setOnClickListener(v -> { if (!editor.redo()) Ui.toast(this, "Niente da ripristinare"); });
        findViewById(R.id.btnGoto).setOnClickListener(v -> askGoToLine());
        findViewById(R.id.btnFind).setOnClickListener(v -> {
            boolean show = findBar.getVisibility() != View.VISIBLE;
            findBar.setVisibility(show ? View.VISIBLE : View.GONE);
            if (show) etFind.requestFocus();
        });
        findViewById(R.id.btnSave).setOnClickListener(v -> {            // salvataggio manuale
            if (currentFile == null) return;
            saveCurrent(() -> Ui.toast(this, "Salvato"));
        });
        findViewById(R.id.btnMore).setOnClickListener(v -> {
            PopupMenu pm = new PopupMenu(this, v);
            pm.getMenu().add(0, 1, 0, "Scegli entry point...");
            pm.getMenu().add(0, 2, 1, "Copia log");
            pm.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == 1) chooseEntry();
                else copyLog();
                return true;
            });
            pm.show();
        });
        fab.setOnClickListener(v -> onRunClicked());
    }

    private void setupFindBar() {
        findViewById(R.id.btnFindNext).setOnClickListener(v -> doFind(true));
        findViewById(R.id.btnFindPrev).setOnClickListener(v -> doFind(false));
        findViewById(R.id.btnFindClose).setOnClickListener(v -> findBar.setVisibility(View.GONE));
        etFind.setOnEditorActionListener((v, id, e) -> { doFind(true); return true; });
        findViewById(R.id.btnReplace).setOnClickListener(v -> {
            String q = etFind.getText().toString();
            if (!editor.replaceCurrent(q, etReplace.getText().toString(), cbCase.isChecked())) Ui.toast(this, "Nessun risultato");
        });
        findViewById(R.id.btnReplaceAll).setOnClickListener(v -> {
            int n = editor.replaceAll(etFind.getText().toString(), etReplace.getText().toString(), cbCase.isChecked());
            Ui.toast(this, n + " sostituzioni");
        });
    }

    private void doFind(boolean forward) {
        if (!editor.find(etFind.getText().toString(), forward, cbCase.isChecked())) Ui.toast(this, "Nessun risultato");
    }

    private void askGoToLine() {
        final int max = editor.lineCount();
        Ui.prompt(this, "Vai alla linea (1-" + max + ")", "", s -> {
            try {
                int n = Integer.parseInt(s.trim());
                editor.goToLine(Math.max(1, Math.min(n, max)));
            } catch (NumberFormatException e) {
                Ui.toast(this, "Numero non valido");
            }
        });
    }

    private void setupLog() {
        tvLog.setMovementMethod(LinkMovementMethod.getInstance());
        findViewById(R.id.btnLogClear).setOnClickListener(v -> { tvLog.setText(""); editor.clearMarks(); });
        btnLogStop.setOnClickListener(v -> active().stop());
        findViewById(R.id.btnLogToggle).setOnClickListener(v -> {
            boolean open = logBody.getVisibility() != View.VISIBLE;
            logBody.setVisibility(open ? View.VISIBLE : View.GONE);
            ((Button) v).setText(open ? "▾" : "▸");
        });
        etStdin.setOnEditorActionListener((v, id, e) -> {
            String line = etStdin.getText().toString();
            etStdin.setText("");
            if (active().isRunning()) {
                if (active().sendInput(line)) appendLog("> " + line + "\n", C_INFO);
                else Ui.toast(this, "Input interattivo non disponibile con Termux");
            }
            return true;
        });
    }

    private void setupExtraKeys() {
        LinearLayout row = findViewById(R.id.extraKeysRow);
        String[][] keys = {{"⇥", "    "}, {"(", "("}, {")", ")"}, {"[", "["}, {"]", "]"}, {"{", "{"}, {"}", "}"},
                {":", ":"}, {"=", "="}, {"\"", "\""}, {"'", "'"}, {"_", "_"}, {"#", "#"}, {".", "."}, {",", ","}};
        for (final String[] k : keys) {
            Button bt = new Button(this);
            bt.setText(k[0]);
            bt.setTextColor(0xFFD7DAE0);
            bt.setAllCaps(false);
            bt.setBackground(null);
            bt.setMinWidth(0);
            bt.setMinimumWidth(Ui.dp(this, 40));
            bt.setOnClickListener(v -> editor.insertAtCursor(k[1]));
            row.addView(bt, new LinearLayout.LayoutParams(-2, -1));
        }
    }

    /** Con la tastiera aperta: nasconde log e Play, mostra i tasti rapidi (più spazio all'editor). */
    private void setupKeyboardWatcher() {
        final View root = findViewById(R.id.root);
        root.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect r = new Rect();
            root.getWindowVisibleDisplayFrame(r);
            boolean kb = root.getRootView().getHeight() - r.height() > Ui.dp(this, 150);
            if (kb == keyboardVisible) return;
            keyboardVisible = kb;
            logPanel.setVisibility(kb ? View.GONE : View.VISIBLE);
            fab.setVisibility(kb ? View.GONE : View.VISIBLE);
            extraKeys.setVisibility(kb ? View.VISIBLE : View.GONE);
        });
    }

    private void applyPrefs() {
        editor.setEditorTextSize(prefs.fontSize());
        if (prefs.keepScreenOn()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ================================================================== sidebar

    private void setupSidebar() {
        tree = new FileTreeAdapter(this);
        ListView lv = findViewById(R.id.lvFiles);
        lv.setAdapter(tree);
        lv.setOnItemClickListener((p, v, pos, id) -> {
            File f = tree.getItem(pos).file;
            if (f.isDirectory()) tree.toggle(f);
            else { openFile(f, -1); toggleSidebar(false); }
        });
        lv.setOnItemLongClickListener((p, v, pos, id) -> { showNodeMenu(v, tree.getItem(pos).file); return true; });

        scrim.setOnClickListener(v -> toggleSidebar(false));
        findViewById(R.id.btnNewFile).setOnClickListener(v -> newFile(projectDir));
        findViewById(R.id.btnNewFolder).setOnClickListener(v -> newFolder(projectDir));
        findViewById(R.id.btnProjects).setOnClickListener(v -> showProjects());
        tvEntry.setOnClickListener(v -> chooseEntry());
        findViewById(R.id.btnTerminal).setOnClickListener(v -> {
            toggleSidebar(false);
            ToolDialogs.terminal(this, terminal, projectDir);
        });
        findViewById(R.id.btnPip).setOnClickListener(v -> {
            toggleSidebar(false);
            if (pipDialog == null) pipDialog = new ToolDialogs.PipDialog(this, pip, this::pickWheel, this::runTermuxInstall);
            pipDialog.show();
        });
        findViewById(R.id.btnTermux).setOnClickListener(v -> {
            toggleSidebar(false);
            openTermuxHere();
        });
        findViewById(R.id.btnSettings).setOnClickListener(v -> {
            toggleSidebar(false);
            ToolDialogs.settings(this, prefs, effectiveBackend(), this::onSettingsChanged);
        });
    }

    private void toggleSidebar(boolean open) {
        sidebarOpen = open;
        scrim.setVisibility(open ? View.VISIBLE : View.GONE);
        sidebar.animate().translationX(open ? 0 : -sidebar.getWidth()).setDuration(180).start();
    }

    private void refreshTree() {
        if (projectDir == null) return;
        File entry = projects.getEntry(projectDir);
        tree.reload(projectDir, entry, currentFile);
        tvEntry.setText("Entry point: " + projects.relative(projectDir, entry) + "  (tocca per cambiare)");
    }

    private void pickWheel() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        startActivityForResult(i, REQ_WHEEL);
    }

    // ------------------------------------------------------- menu file/cartella

    private void showNodeMenu(View anchor, final File f) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "Nuovo file qui");
        m.add(0, 2, 1, "Nuova cartella qui");
        m.add(0, 3, 2, "Rinomina");
        m.add(0, 4, 3, "Sposta in...");
        m.add(0, 5, 4, "Elimina");
        if (f.isFile() && f.getName().endsWith(".py")) m.add(0, 6, 5, "Imposta come entry point");
        final File parent = f.isDirectory() ? f : f.getParentFile();
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: newFile(parent); break;
                case 2: newFolder(parent); break;
                case 3: renameNode(f); break;
                case 4: moveNode(f); break;
                case 5: deleteNode(f); break;
                case 6: setEntry(f); break;
            }
            return true;
        });
        pm.show();
    }

    private interface IoTask {
        File run() throws IOException;
    }

    /** Esegue un'operazione sui file fuori dal thread UI, poi aggiorna l'albero. */
    private void fileOp(final IoTask task, final Consumer<File> onOk) {
        io.execute(() -> {
            try {
                final File r = task.run();
                runOnUiThread(() -> {
                    if (onOk != null) onOk.accept(r);
                    refreshTree();
                });
            } catch (final IOException e) {
                runOnUiThread(() -> Ui.toast(this, "Errore: " + e.getMessage()));
            }
        });
    }

    private void newFile(final File parent) {
        Ui.prompt(this, "Nuovo file", "", name -> fileOp(
                () -> FileOps.createFile(projectDir, parent, name),
                f -> { tree.expand(parent); openFile(f, -1); }));
    }

    private void newFolder(final File parent) {
        Ui.prompt(this, "Nuova cartella", "", name -> fileOp(
                () -> FileOps.createDir(projectDir, parent, name),
                f -> tree.expand(parent)));
    }

    private void renameNode(final File f) {
        Ui.prompt(this, "Rinomina", f.getName(), name -> fileOp(
                () -> FileOps.rename(projectDir, f, name), nf -> remap(f, nf)));
    }

    private void moveNode(final File f) {
        final List<File> dirs = FileOps.listDirs(projectDir);
        String[] labels = new String[dirs.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = i == 0 ? "/ (radice del progetto)" : "/" + projects.relative(projectDir, dirs.get(i));
        }
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Sposta \"" + f.getName() + "\" in").setItems(labels, (d, i) -> {
                    final File dest = dirs.get(i);
                    fileOp(() -> FileOps.move(projectDir, f, dest), nf -> { tree.expand(dest); remap(f, nf); });
                }).show();
    }

    private void deleteNode(final File f) {
        Ui.confirm(this, "Elimina", "Eliminare \"" + f.getName() + "\""
                + (f.isDirectory() ? " e tutto il suo contenuto" : "") + "?", () -> fileOp(() -> {
            FileOps.delete(projectDir, f);
            return null;
        }, r -> {
            if (currentFile != null && FileOps.isInside(f, currentFile)) {
                currentFile = null;
                dirty = false;
                editor.setContent("", "text");
                updateTitle();
            }
        }));
    }

    /** Dopo rinomina/spostamento aggiorna file aperto ed entry point. */
    private void remap(File oldF, File newF) {
        try {
            File entry = projects.getEntry(projectDir);
            if (FileOps.isInside(oldF, entry)) {
                projects.setEntry(projectDir, new File(newF, oldF.toURI().relativize(entry.toURI()).getPath()));
            }
        } catch (IOException ignored) {
        }
        if (currentFile != null && FileOps.isInside(oldF, currentFile)) {
            currentFile = new File(newF, oldF.toURI().relativize(currentFile.toURI()).getPath());
            updateTitle();
        }
    }

    // ------------------------------------------------- entry point e progetti

    private void setEntry(File f) {
        try {
            projects.setEntry(projectDir, f);
            refreshTree();
            Ui.toast(this, "Entry point: " + f.getName());
        } catch (IOException e) {
            Ui.toast(this, e.getMessage());
        }
    }

    private void chooseEntry() {
        if (projectDir == null) return;
        final List<File> py = new ArrayList<>();
        collectPy(projectDir, py, 0);
        if (py.isEmpty()) { Ui.toast(this, "Nessun file .py nel progetto"); return; }
        String[] labels = new String[py.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = projects.relative(projectDir, py.get(i));
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Script di partenza (tasto Play)").setItems(labels, (d, i) -> setEntry(py.get(i))).show();
    }

    private void collectPy(File dir, List<File> out, int depth) {
        File[] kids = dir.listFiles();
        if (kids == null || depth > 6) return;
        java.util.Arrays.sort(kids);
        for (File k : kids) {
            if (k.isDirectory() && !k.getName().startsWith(".")) collectPy(k, out, depth + 1);
            else if (k.isFile() && k.getName().endsWith(".py")) out.add(k);
        }
    }

    private void showProjects() {
        final List<String> names = projects.list();
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Progetti").setItems(names.toArray(new String[0]), (d, i) -> openProject(projects.dir(names.get(i))))
                .setNeutralButton("Nuovo progetto", (d, w) -> Ui.prompt(this, "Nome del progetto", "", this::createAndOpenProject))
                .setNegativeButton("Elimina corrente", (d, w) -> Ui.confirm(this, "Elimina progetto",
                        "Eliminare definitivamente \"" + projectDir.getName() + "\" e tutti i suoi file?", this::deleteCurrentProject))
                .show();
    }

    private void createAndOpenProject(final String name) {
        io.execute(() -> {
            try {
                final File d = projects.create(name);
                runOnUiThread(() -> openProject(d));
            } catch (final IOException e) {
                runOnUiThread(() -> Ui.toast(this, "Errore: " + e.getMessage()));
            }
        });
    }

    private void deleteCurrentProject() {
        final File d = projectDir;
        currentFile = null;
        dirty = false;
        io.execute(() -> {
            try {
                projects.delete(d);
            } catch (IOException e) {
                runOnUiThread(() -> Ui.toast(this, "Errore: " + e.getMessage()));
            }
            runOnUiThread(() -> {
                List<String> left = projects.list();
                if (left.isEmpty()) createAndOpenProject("MioProgetto");
                else openProject(projects.dir(left.get(0)));
            });
        });
    }

    private void openProject(File dir) {
        if (dirty && currentFile != null) saveCurrent(null);
        projectDir = dir;
        currentFile = null;
        pendingReport = null;
        prefs.setLastProject(dir.getName());
        tvProject.setText("Progetto: " + dir.getName());
        refreshTree();
        File entry = projects.getEntry(dir);
        if (entry.exists()) openFile(entry, -1);
        else { editor.setContent("", "text"); updateTitle(); }
    }

    // ================================================================ file/editor

    private void openFile(final File f, final int line) {
        if (f.equals(currentFile)) { afterOpen(line); return; }
        if (dirty && currentFile != null) saveCurrent(null);
        if (f.length() > 2L * 1024 * 1024) { Ui.toast(this, "File troppo grande per l'editor (> 2 MB)"); return; }
        final int token = ++openToken;
        io.execute(() -> {
            String text = null;
            String err = null;
            try {
                byte[] b = Files.readAllBytes(f.toPath());
                for (int i = 0; i < Math.min(b.length, 4096); i++) if (b[i] == 0) { err = "File binario: non modificabile qui"; break; }
                if (err == null) text = new String(b, StandardCharsets.UTF_8);
            } catch (IOException e) {
                err = e.getMessage();
            }
            final String t = text, e = err;
            runOnUiThread(() -> {
                if (token != openToken) return;                  // apertura superata da una più recente
                if (e != null) { Ui.toast(this, e); return; }
                currentFile = f;
                editor.setContent(t, SyntaxHighlighter.langFor(f.getName()));
                dirty = false;
                refreshTree();
                updateTitle();
                afterOpen(line);
            });
        });
    }

    private void afterOpen(int line) {
        if (pendingReport != null) editor.setMarks(pendingReport.marksFor(currentFile));
        if (line > 0) editor.goToLine(line);
    }

    private void updateTitle() {
        String name = currentFile == null || projectDir == null ? "PyIDE" : projects.relative(projectDir, currentFile);
        tvTitle.setText((dirty ? "● " : "") + name);
    }

    /** Salva il file corrente in background; il callback gira sul thread UI. */
    private void saveCurrent(final Runnable after) {
        if (currentFile == null) { if (after != null) after.run(); return; }
        final int v = editVersion;
        saver.submit(currentFile, editor.getText().toString(), (f, ok, error) -> {
            if (!ok) { Ui.toast(this, "Salvataggio fallito: " + error); return; }
            if (v == editVersion && f.equals(currentFile)) { dirty = false; updateTitle(); }
            if (after != null) after.run();
        });
    }

    // ============================================================ esecuzione + log

    private void onRunClicked() {
        if (active().isRunning()) { active().stop(); return; }              // lo stesso pulsante ferma
        if (projectDir == null) return;
        if (isTermux() && !termuxReady()) { showTermuxSetup(); return; }
        final File entry = projects.getEntry(projectDir);                  // SEMPRE lo script di partenza
        if (!entry.exists()) {
            Ui.toast(this, "Entry point non trovato: " + entry.getName());
            chooseEntry();
            return;
        }
        if (dirty && currentFile != null) saveCurrent(() -> startRun(entry));
        else startRun(entry);
    }

    private void startRun(File entry) {
        if (prefs.clearLogOnRun()) tvLog.setText("");
        stderrBuf.setLength(0);
        pendingReport = null;
        editor.clearMarks();
        logBody.setVisibility(View.VISIBLE);
        appendLog(ts() + "Avvio " + projects.relative(projectDir, entry) + "...\n", C_INFO);
        if (!isTermux()) RunnerService.start(this, "Script in esecuzione: " + entry.getName());
        active().run(projectDir, entry, new ScriptRunner.Listener() {
            @Override public void onStart() { setRunning(true); }

            @Override public void onOutput(String text, boolean isError) {
                appendLog(text, isError ? C_ERR : C_OUT);
                if (isError && stderrBuf.length() < 200_000) stderrBuf.append(text);
            }

            @Override public void onFinish(int code, long ms, boolean stopped) {
                setRunning(false);
                RunnerService.stop(MainActivity.this);
                String secs = String.format(Locale.US, "%.1f", ms / 1000.0);
                if (stopped) appendLog(ts() + "Interrotto dall'utente (" + secs + " s)\n", C_WARN);
                else if (code == 0) appendLog(ts() + "Terminato con successo (" + secs + " s)\n", C_OK);
                else appendLog(ts() + "Terminato con codice " + code + " (" + secs + " s)\n", C_ERR);
                if (!stopped && code != 0) analyzeError();
            }
        });
    }

    private void setRunning(boolean running) {
        fab.setText(running ? "■" : "▶");
        fab.getBackground().mutate().setTint(running ? 0xFFE0453A : 0xFF30B35C);
        btnLogStop.setVisibility(running ? View.VISIBLE : View.GONE);
    }

    /** Analisi intelligente dell'errore: tipo, riga, cause collegate, evidenziazione nell'editor. */
    private void analyzeError() {
        final ErrorAnalyzer.Report r = ErrorAnalyzer.analyze(stderrBuf.toString(), projectDir);
        if (r == null) return;
        pendingReport = r;

        appendLog("\n■ " + r.kindLabel() + " — " + r.type + "\n", C_ERR);
        if (!r.message.isEmpty()) appendLog("  " + r.message + "\n", C_ERR);
        if (r.errorFrame != null) {
            appendLink("  ● Errore alla riga " + r.errorFrame.line + " — " + r.errorFrame.file.getName() + "\n", C_ERR, r.errorFrame);
        }
        for (ErrorAnalyzer.Frame f : r.callChain) {
            appendLink("  ○ Chiamata alla riga " + f.line + " — " + f.file.getName() + (f.func != null ? " (" + f.func + ")" : "") + "\n", C_WARN, f);
        }
        for (ErrorAnalyzer.Frame f : r.chained) {
            appendLink("  ○ Eccezione collegata, riga " + f.line + " — " + f.file.getName() + "\n", C_WARN, f);
        }
        for (ErrorAnalyzer.Frame f : r.probable) {
            appendLink("  ◌ Causa probabile: '" + f.func + "' assegnata alla riga " + f.line + " — " + f.file.getName() + "\n", 0xFFE5C07B, f);
        }

        ErrorAnalyzer.Frame ef = r.errorFrame;
        if (ef != null && ef.inProject) {
            Ui.toast(this, r.kindLabel() + " alla riga " + ef.line);
            openFile(ef.file, ef.line);                       // apre il file e segna le righe
        }
    }

    private void appendLink(String text, int color, final ErrorAnalyzer.Frame f) {
        SpannableString ss = new SpannableString(text);
        ss.setSpan(new ForegroundColorSpan(color), 0, ss.length(), 0);
        ss.setSpan(new ClickableSpan() {
            @Override public void onClick(View w) { openFile(f.file, f.line); }
            @Override public void updateDrawState(TextPaint p) { p.setUnderlineText(true); }
        }, 0, ss.length(), 0);
        tvLog.append(ss);
        scrollLog();
    }

    private void appendLog(CharSequence s, int color) {
        SpannableString ss = new SpannableString(s);
        ss.setSpan(new ForegroundColorSpan(color), 0, ss.length(), 0);
        tvLog.append(ss);
        CharSequence cur = tvLog.getText();
        int limit = prefs.logLimit();
        if (cur instanceof Editable && cur.length() > limit) {          // protegge la memoria
            ((Editable) cur).delete(0, cur.length() - limit * 3 / 4);
        }
        scrollLog();
    }

    private void scrollLog() {
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("log", tvLog.getText()));
        Ui.toast(this, "Log copiato");
    }

    // ====================================================== backend, storage, Termux

    private String effectiveBackend() {
        String b = prefs.backend();
        if (b.isEmpty()) b = pyEnv.isBinaryPresent() ? "embedded" : "termux";
        return b;
    }

    private boolean isTermux() {
        return effectiveBackend().equals("termux");
    }

    private ScriptRunner active() {
        return isTermux() ? termuxRunner : embedded;
    }

    private boolean hasAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } else {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 2);
        }
    }

    /** Sceglie la cartella dei progetti (condivisa se serve a Termux e il permesso c'è). */
    private void initProjects() {
        sharedWanted = prefs.sharedProjects() || isTermux();
        boolean useShared = sharedWanted && hasAllFiles();
        if (sharedWanted && !useShared) {
            Ui.toast(this, "Concedi \"Accesso a tutti i file\" a PyIDE per usare la cartella condivisa");
            requestAllFiles();
        }
        projects = new ProjectManager(this, useShared);
    }

    private void onSettingsChanged() {
        applyPrefs();
        File keep = projectDir;
        initProjects();
        List<String> l = projects.list();
        if (keep != null && projects.dir(keep.getName()).isDirectory()) openProject(projects.dir(keep.getName()));
        else if (l.isEmpty()) createAndOpenProject("MioProgetto");
        else openProject(projects.dir(l.get(0)));
    }

    private boolean termuxReady() {
        return termuxBridge.isInstalled() && termuxBridge.hasPermission() && projects.isShared();
    }

    /** Procedura guidata: cosa manca per usare Termux, con comandi da copiare. */
    private void showTermuxSetup() {
        StringBuilder sb = new StringBuilder();
        sb.append(termuxBridge.isInstalled() ? "✔ Termux installato\n"
                : "✖ Installa Termux da F-Droid o GitHub (non dal Play Store)\n");
        sb.append(termuxBridge.hasPermission() ? "✔ Permesso \"Esegui comandi in Termux\" concesso\n"
                : "✖ Concedi a PyIDE il permesso \"Esegui comandi in Termux\"\n");
        sb.append(projects.isShared() ? "✔ Cartella condivisa /sdcard/PyIDE attiva\n"
                : "✖ Concedi a PyIDE \"Accesso a tutti i file\" (cartella condivisa)\n");
        sb.append("\nIn Termux, incolla (poi concedi lo storage e riapri Termux):\n\n")
                .append(TermuxBridge.SETUP_COMMANDS);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Configura Termux").setMessage(sb.toString())
                .setNeutralButton("Copia comandi", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("termux", TermuxBridge.SETUP_COMMANDS));
                    Ui.toast(this, "Comandi copiati: incollali in Termux");
                })
                .setNegativeButton("Apri Termux", (d, w) -> termuxBridge.openApp())
                .setPositiveButton("Permessi", (d, w) -> {
                    if (termuxBridge.isInstalled() && !termuxBridge.hasPermission()) {
                        requestPermissions(new String[]{TermuxBridge.PERM}, 3);
                    } else if (!projects.isShared()) {
                        requestAllFiles();
                    }
                }).show();
    }

    /** Apre una sessione Termux visibile nella cartella del progetto. */
    private void openTermuxHere() {
        if (!termuxBridge.isInstalled() || !termuxBridge.hasPermission()) { showTermuxSetup(); return; }
        String dir = projectDir != null && projects.isShared() ? projectDir.getAbsolutePath() : TermuxBridge.HOME;
        String err = termuxBridge.runForeground("cd " + TermuxBridge.q(dir) + " 2>/dev/null; exec bash -l", dir);
        if (err != null) Ui.toast(this, err);
        termuxBridge.openApp();
    }

    /** Installazioni pesanti eseguite da Termux, con log in tempo reale nel dialogo PIP. */
    private void runTermuxInstall(final String command, final PipManager.Callback cb) {
        if (!termuxReady()) {
            showTermuxSetup();
            cb.onDone(false, "Termux non è pronto: completa la configurazione guidata.");
            return;
        }
        File jobDir = new File(projects.root().getParentFile(), ".jobs/install");
        final TermuxJob job = new TermuxJob(termuxBridge, jobDir);
        final StringBuilder all = new StringBuilder();
        final StringBuilder partial = new StringBuilder();
        String err = job.start(command, TermuxBridge.HOME, new TermuxJob.Listener() {
            @Override public void onOutput(String text, boolean isError) {
                if (all.length() < 200_000) all.append(text);
                partial.append(text.replace("\r", "\n"));
                int nl;
                while ((nl = partial.indexOf("\n")) >= 0) {
                    String line = partial.substring(0, nl);
                    partial.delete(0, nl + 1);
                    if (!line.trim().isEmpty()) cb.onLog(line);
                }
            }

            @Override public void onExit(int code, boolean stopped, String problem) {
                if (partial.length() > 0) cb.onLog(partial.toString());
                if (problem != null) { cb.onDone(false, problem); return; }
                String log = all.toString();
                if (code == 0) { cb.onDone(true, "Comando completato in Termux."); return; }
                String why = log.contains("externally-managed-environment")
                        ? "Termux blocca pip fuori da un venv: riprova con il pulsante \"pip in Termux\" di PyIDE."
                        : log.contains("not found") && log.contains("pkg") ? "Pacchetto non trovato: prova \"Repo extra\" e poi pkg search."
                        : PipManager.explain(log);
                cb.onDone(false, why + " (codice " + code + ")");
            }
        });
        if (err != null) cb.onDone(false, err);
    }

    private static String ts() {
        return "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] ";
    }
}
